#!/bin/bash
#-------------------------------------------------------------------#
# 特定の開始・終了キーワード間の複数行を置換
#-------------------------------------------------------------------#

#------ 初期化
sh_name=${0##*/}
in_file=${1}
tg_file=${2}

sta_keyword='#-----LinuxHosts_sta-----#'
end_keyword='#-----LinuxHosts_end-----#'
sta_line=`grep -n ${sta_keyword} ${tg_file} | cut -d: -f 1`
end_line=`grep -n ${end_keyword} ${tg_file} | cut -d: -f 1`

#------ list形式のチェック
while read line || [ -n "${line}" ]
do
	chk_ip=$(echo ${line} | sed -e "s/[\r\n]\+//g" | egrep "^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$")
	if [ ! "${chk_ip}" ]; then
		echo "[${sh_name}] ERR: list.txtの形式が不正です!"
		exit 9
	fi
done < ${in_file}

#------ ファイルの部分初期化とバックアップ
((int_diff=end_line-sta_line))
if [ ${int_diff} -gt 1 ]; then
	((sta_del=sta_line+1))
	((end_del=end_line-1))
	sed --in-place=.bak -e "${sta_del},${end_del}d" ${tg_file}
fi

#------ 追加ファイルの読込とsed文字列生成
while read line || [ -n "${line}" ]
do
	if [ -n "${sed_str}" ]; then
		sed_str="${sed_str}\n${line}"
	else
		sed_str="${line}"
	fi
done < ${in_file}

#------ sed実行による置換
((sta_in=sta_line+1))
sed --in-place -e "${sta_in}i ${sed_str}" ${tg_file}
