#!/bin/bash

cd /y/seclog/pyyiz001_tartest
tar zxvf /tmp/ikou/config.yiscodef.tar.gz
tar zxvf /tmp/ikou/hkn_inf.tar.gz
tar zxvf /tmp/ikou/data.tar.gz
tar zxvf /tmp/ikou/shell.tar.gz
tar zxvf /tmp/ikou/yighhlog.tar.gz
tar zxvf /tmp/ikou/yighilog.tar.gz
tar zxvf /tmp/ikou/yighulog.tar.gz
tar zxvf /tmp/ikou/yilhhlog.tar.gz
tar zxvf /tmp/ikou/yilhilog.tar.gz
tar zxvf /tmp/ikou/yilhulog.tar.gz
tar zxvf /tmp/ikou/yilm.tar.gz
tar zxvf /tmp/ikou/yilo.tar.gz
tar zxvf /tmp/ikou/yilu.tar.gz
tar zxvf /tmp/ikou/yilz.tar.gz
tar zxvf /tmp/ikou/yioi.tar.gz
tar zxvf /tmp/ikou/yiou.tar.gz
tar zxvf /tmp/ikou/yiow.tar.gz
tar zxvf /tmp/ikou/yipb.tar.gz
tar zxvf /tmp/ikou/yisp.tar.gz
tar zxvf /tmp/ikou/iko_tools.tar.gz