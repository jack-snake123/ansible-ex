#!/bin/ksh

######################################<+>#######################################
#  File              : yilmlogc.sh
#  Project           : セキュリティログ監理支援システム
#  Description       : セキュリティログ収集処理
#  Language          : ksh
#  Date              : 2003.10.11
#  Author            : 基盤技術センター
#  Update            : 
######################################<+>#######################################

#-----------------------------------------------------------------------------
# デバッグ用関数
#-----------------------------------------------------------------------------
echo_proc ()
{
    #引数を全て標準出力に出力する
    echo "$*" >> /tmp/yilmlogc_log.txt
    return 0
}

#-----------------------------------------------------------------------------
# 定数定義
#-----------------------------------------------------------------------------
    #セキュリティログ収集処理-処理結果
    NORMAL_FLG=0                            #正常
    ERROR_FLG=1                             #異常
    COL_ERROR_FLG=2                         #収集エラー

    #現在処理日・処理時間
    CNS_YMD=`date +"%Y%m%d"`                #日付
    CNS_HMS=`date +"%H%M%S"`                #時間

    #その他定数
    CHECK_0=0                               #数字チェック用定数(0チェック)
    CHECK_1=1                               #数字チェック用定数(1チェック)

    #閏年判定用
    CHECK_LEAP=0                            #閏年
    CHECK_NOT_LEAP=1                        #閏年以外

    #月、日定数
    MM_01=1                                 #１月
    MM_02=2                                 #２月
    MM_12=12                                #１２月
    YY_LEN=4                                #年-文字列長
    MM_LEN=2                                #月-文字列長
    DD_LEN=2                                #日-文字列長
    MONTH_DAYS=""31" "28" "31" "30" "31" "30" "31" "31" "30" "31" "30" "31""
                                            #月-日付関連

    #日付形式チェック
    YMD_TYPE="[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]"
                                            #日付-"YYYYMMDD形式"

    #ログ種別用ディレクトリ名称
    LOG_SBT_N_DIR="ninshou"                 #認証ログ
    LOG_SBT_A_DIR="access"                  #アクセスログ
    LOG_SBT_O_DIR="operation"               #オペレーションログ
    LOG_SBT_E_DIR="etc"                     #その他ログ
    #
    # 2004.08.05 追加
    #
    LOG_SBT_C_DIR="acount"                  #アカウントログ
    LOG_SBT_T_DIR="trace"                   #トレースログ

    #ログ種別チェック
    LOG_SBT_N="N"                           #認証ログ
    LOG_SBT_A="A"                           #アクセスログ
    LOG_SBT_O="O"                           #オペレーションログ
    LOG_SBT_E="E"                           #その他ログ
    #
    # 2004.08.05 追加
    #
    LOG_SBT_C="C"                           #アカウントログ
    LOG_SBT_T="T"                           #トレースログ

    CHECK_RT_NORMAL=0                       #リトライ期間内
    CHECK_RT_EQUAL=1                        #リトライ期限
    CHECK_RT_ERROR=2                        #リトライ期間外

#-----------------------------------------------------------------------------
# 収集定義ファイル項目定数
#-----------------------------------------------------------------------------
    #収集定義ファイル項目番号（配列番号）
    COL_REC_KSU=4                           #レコード数（項目数）
    COL_DEF=0                               #収集構成定義格納先
    COL_RES=1                               #収集結果格納先
    COL_SVR=2                               #サーバ区分
    COL_RET=3                               #リトライ期間

    #サーバ区分
    SVR_MGR="0"                             #監理サーバ
    SVR_COL="1"                             #収集サーバ

#-----------------------------------------------------------------------------
# 収集構成定義ファイル項目定数
#-----------------------------------------------------------------------------
    #収集構成定義ファイル項目番号（配列番号）
    CMP_KMK_KSU=8                           #項目数
    CMP_SVR=0                               #サーバ（サーバ名）
    CMP_SVR_JP=1                            #サーバ（日本語名）
    CMP_SVR_IP=2                            #サーバ（IPアドレス）
    CMP_BGN_YMD=3                           #運用開始日
    CMP_COL_SBT=4                           #収集種別
    CMP_LOG_SBT=5                           #ログファイル種類
    CMP_LOG_DIR=6                           #ログファイル格納先
    CMP_LOG_FILE=7                          #ログファイル名コンベンション

#-----------------------------------------------------------------------------
# 収集結果ファイル項目定数
#-----------------------------------------------------------------------------
    #収集結果
    COL_RES_GET=1                           #セキュリティログ有
    COL_RES_NON=0                           #セキュリティログ無
    COL_RES_ERR=2                           #セキュリティログ収集エラー

#-----------------------------------------------------------------------------
# FTP接続関連定数
#-----------------------------------------------------------------------------

    #FTP-GET実行結果確認定数
    #環境によって変化する可能性があるため注意
    FTP_CONNECT_ERROR="Not connected."      #接続エラー
    FTP_CERTIFY_ERROR1="Login incorrect."   #認証エラー１
    FTP_CERTIFY_ERROR2="Login failed."      #認証エラー２
    FTP_FILE_ERROR="No such file or directory."
                                            #ファイル、またはディレクトリ無し

    #FTP-GETPUT ログ監理サーバIPアドレス 2022/9/～ リプレース以降
    #PUT_ftpIP=130.127.36.41    #IP切り替え後 千葉ログ監理サーバ
    PUT_ftpIP=145.13.0.50     #IP切り替え後 埼玉ログ監理サーバ
    #PUT_ftpIP=10.170.194.29  #開発環境ログ監理サーバ

    #ログ監理サーバ FTPユーザ パスワード
    PUT_ftpUser="pyyiz001"
    PUT_ftpPass="pyyiz111"

#-----------------------------------------------------------------------------
# alias定義
#-----------------------------------------------------------------------------
    #rmコマンド（確認無し）
    alias rm="rm -f"
    #mvコマンド（確認無し）
    alias mv="mv -f"
    #grepコマンド（エラーメッセージ無し）
    alias grep="grep -s"
    #mkdirコマンド（中間ディレクトリ作成）
    alias mkdir="mkdir -p"
    #rmdirコマンド（エラーメッセージ無し）
    alias rmdir="rmdir -s"
    #ftpコマンド（自動ログイン無し）
    alias ftp="ftp -n -i"
    #mountコマンド
    alias mount="/usr/sbin/mount"
    #umountコマンド
    alias umount="/usr/sbin/umount"

#-----------------------------------------------------------------------------
# 使用ディレクトリパス定義
#-----------------------------------------------------------------------------
    #セキュリティログ監理支援システム規定ディレクトリ
    DIR_HOME="/y/seclog/pyyiz001/yilm"      #ホームディレクトリ
    DIR_CONF="/y/seclog/pyyiz001/yilm/config"
                                            #コンフィグ情報格納ディレクトリ
    DIR_PGM="/y/seclog/pyyiz001/yilm/sbin"  #プログラム格納ディレクトリ
    DIR_SEC_LOG_1="/log"                    #作業領域１（監理サーバ）
    DIR_SEC_LOG_2="/y/seclog/pyyiz001/YI_WORK"
                                            #作業領域２（収集サーバ）
    DIR_TEMP_AREA="temparea"                #セキュリティログ格納一時領域
    DIR_TRACELOG="/togounyo/syslog/trace/yi"
                                            #トレースログ格納先

    #各種作業領域
    DIR_WORK="yilmlogc"                     #作業領域
    DIR_LOG="logfile"                       #FTP-GET時のログファイル格納先

#-----------------------------------------------------------------------------
# 使用ファイル定義
#-----------------------------------------------------------------------------
    #セキュリティログ監理支援システム規定ファイル
    FILE_YICDEF="yicdef.txt"                #収集定義ファイル
    FILE_YICCODEF="yiccodef.txt"            #収集構成定義ファイル
    FILE_YICAGN="yicagn.txt"                #再収集情報ファイル
    FILE_YICTRRES="yictrres.txt"            #収集処理稼動結果ファイル
    FILE_TRACELOG="yilmlogc-${CNS_YMD}.txt" #トレースログ
    FILE_YICRES="yicres.txt"                #収集結果ファイル

    #各種作業ファイル
    FILE_FTP_RES="ftp-res.txt"              #FTP-GETの結果ファイル
    FILE_FTP_ACT="ftp-act.txt"              #FTP実行時の標準入力

#-----------------------------------------------------------------------------
# ファイル構成定義
#-----------------------------------------------------------------------------
    #各ファイル項目区切り文字
    #ユーザ設定ファイル
    #  収集定義ファイル
    KGI_USER=","

    #プログラム作成ファイル
    #  再収集情報ファイル、収集処理稼動結果ファイル、収集結果ファイル
    KGI_PGM=","

    #トレースログ
    KGI_TRACE=" *"

    #収集構成定義ファイルは"スペース"または"Tab"

#-----------------------------------------------------------------------------
# 標準出力制御
#-----------------------------------------------------------------------------
    DEV_NULL="/dev/null"                    #標準出力無し

#-----------------------------------------------------------------------------
# トレースログ出力内容定義
#-----------------------------------------------------------------------------
    #キーワード
    TRACE_INFOM="infom"                     #AP稼動情報
    TRACE_ERROR="error"                     #エラー情報(他システム、環境要因)
    TRACE_FATAL="fatal"                     #エラー情報(ジシステム要因)

    #戻り値
    TRACE_NORMAL_FLG=0                      #正常
    TRACE_ERROR_FLG=1                       #異常

    #内容
    #セキュリティログ収集処理実行開始時
    TRACE_001="セキュリティログ収集処理 開始"

    #セキュリティログのFTP接続エラー時
    TRACE_002="セキュリティログ収集エラー（ＦＴＰ接続エラー）"

    #セキュリティログの取得エラー時
    TRACE_003="セキュリティログ収集エラー（セキュリティログ取得エラー）"

    #11/10の仕様変更により不要となったためコメント化
    #ボリュームコピー異常終了時
    #TRACE_004="ボリュームコピー異常終了"

    #収集定義ファイルの内容が正しくない場合
    TRACE_005="収集定義ファイルエラー"

    #引数の指定内容に誤りが有る場合
    TRACE_006="引数指定内容エラー"

    #収集構成定義が存在しない場合
    TRACE_007="収集構成定義ファイル無し"

    #収集構成定義の内容が正しくない場合
    TRACE_008="収集構成定義エラー"

    #セキュリティログ収集処理実行終了時（正常終了時）
    TRACE_009="セキュリティログ収集処理 正常終了"

    #セキュリティログ収集処理実行終了時（異常終了時）                                           
    TRACE_010="セキュリティログ収集処理 異常終了"

    #ログ中継→ログ監理 ログファイルFTPP送信エラーの場合
    TRACE_011="ログ監理サーバ ログファイルFTP-GETPUT送信エラー 再収集情報ファイルに出力 /renkei/yicagn.txt"

    #ログ中継→ログ監理 s収集結果ファイルFTP送信エラーの場合
    TRACE_012="ログ監理サーバ 収集結果ファイル /renkei/yicres.txt FTP送信エラー"

    #ログ中継→ログ監理  再収集情報ファイル、収集処理稼働結果ファイルFTP送信エラーの場合
    TRACE_013="ログ監理サーバ 再収集情報ファイル /renkei/yicagn.txt または 収集処理稼働結果ファイル /renkei/yictrres.txt FTP送信エラー 【正常終了】"

#-----------------------------------------------------------------------------
# 変数定義
#-----------------------------------------------------------------------------
    #グローバルな変数を定義する
    #グローバル変数は変数名+"_"とする

    #作業領域名
    cWrkDir_=""

    #収集構成定義情報格納領域
    iCmpKsu_=0                              #収集構成定義情報件数
    set -A cCmpSvr_                         #サーバ（サーバ名）
    set -A cCmpSvrJp_                       #サーバ（日本語名）
    set -A cCmpSvrIP_                       #サーバ（IPアドレス）
    set -A cCmpBgnYMD_                      #運用開始日
    set -A cCmpColSbt_                      #収集種別
    set -A cCmpLogSbt_                      #ログファイル種類
    set -A cCmpLogDir_                      #ログファイル格納先
    set -A cCmpLogNam_                      #ログファイル名コンベンション

    #関数内の変数については関数内で定義する
    #命名規則は"関数名の頭文字_"+"変数名"とする

# トレースログ出力処理-Start

######################################<->#######################################
#  Name              : outTraceLog
#  Description       : トレースログ出力処理
#  Inputs            : $1         :キーワード
#                    : $2         :戻り値
#                    : $3         :内容
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :
######################################<->#######################################
outTraceLog ()
{

echo_proc " -- トレースログ出力処理 -- "

    otl_cYMD=`date +"%Y%m%d"`               #日付
    otl_cHMS=`date +"%H%M%S"`               #時刻

    #トレースログ出力先ディレクトリ存在チェック
    if [ ! -d "${DIR_TRACELOG}" ]
      #トレースログ出力先ディレクトリが存在しない場合
      then
        #トレースログ出力先ディレクトリ作成
        mkdir "${DIR_TRACELOG}" > "${DEV_NULL}" 2>&1
    fi

    #トレースログの出力
    #  出力内容
    #    "キーワード *日付 *時刻 *戻り値 *内容"
    #  区切り文字
    #    KGI_TRACE:" *"
    echo -e "$1${KGI_TRACE}\c"          >> "${DIR_TRACELOG}/${FILE_TRACELOG}"
    echo -e "${otl_cYMD}${KGI_TRACE}\c" >> "${DIR_TRACELOG}/${FILE_TRACELOG}"
    echo -e "${otl_cHMS}${KGI_TRACE}\c" >> "${DIR_TRACELOG}/${FILE_TRACELOG}"
    echo -e "$2${KGI_TRACE}\c"          >> "${DIR_TRACELOG}/${FILE_TRACELOG}"
    echo "$3"                        >> "${DIR_TRACELOG}/${FILE_TRACELOG}"

    #正常終了
    return ${NORMAL_FLG}

}

# トレースログ出力処理-End


# 収集処理稼動結果ファイル出力処理-Start

######################################<->#######################################
#  Name              : outTransactionResult
#  Description       : 収集処理稼動結果ファイル出力処理
#  Inputs            : $1        :収集処理結果格納先
#                    : $2        :収集種別
#                    : $3        :日付
#                    : $4        :時間
#                    : $5        :処理結果
#  Outputs           : なし
#  Return            : NORMAL_FLG:正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
outTransactionResult ()
{

echo_proc " -- 収集処理稼動結果ファイル出力処理 -- "

    #収集処理稼動結果ファイルには、処理結果を追記する形に修正（11/17）
    #収集処理の処理結果を保持し続けるものとする

    ##収集処理稼動結果ファイルの存在チェック
    #if [ -f "$1/${FILE_YICTRRES}" ]
    #  #収集処理稼動結果ファイルが存在する場合
    #  then
    #   #収集処理稼動結果ファイルの収集種別が引数の収集種別以外のものを一時
    #   #ファイルに出力する(上書き保存)
    #   grep -v  "^$2${KGI_PGM}.*${KGI_PGM}.*${KGI_PGM}.*" \
    #             "$1/${FILE_YICTRRES}" \
    #             > "${cWrkDir_}/${FILE_YICTRRES}"
    #
    #   #収集処理稼動結果ファイルの削除
    #   #  削除するパスに注意
    #   rm "$1/${FILE_YICTRRES}" > "${DEV_NULL}" 2>&1
    #
    #   #一時ファイルを収集処理稼動結果ファイルにリネームする
    #   mv "${cWrkDir_}/${FILE_YICTRRES}" \
    #       "$1/${FILE_YICTRRES}" > "${DEV_NULL}" 2>&1
    #fi

    #収集処理稼動結果ファイル出力内容の編集
    #  出力内容
    #    "収集種別,日付,時間,処理結果"
    #  区切り文字
    #    KGI_PGM:","
    #echo -e "$2${KGI_PGM}\c" >> "$1/${FILE_YICTRRES}"
    #echo -e "$3${KGI_PGM}\c" >> "$1/${FILE_YICTRRES}"
    #echo -e "$4${KGI_PGM}\c" >> "$1/${FILE_YICTRRES}"
    #echo "$5"             >> "$1/${FILE_YICTRRES}"

    #正常終了
    return ${NORMAL_FLG}

}

# 収集処理稼動結果ファイル出力処理-End


# 収集定義情報取得処理-Start

######################################<->#######################################
#  Name              : getCollectData
#  Description       : 収集定義情報取得処理
#  Inputs            : $1         :収集定義ファイル
#  Outputs           : 収集定義情報（配列形式）
#  Return            : NORMAL_FLG :正常終了
#                    : ERROR_FLG  :異常終了
#  Procedures Called : isNumeric  :数値チェック処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getCollectData ()
{

echo_proc " -- 収集定義情報取得処理 -- "

    gcd_cColRec=""                          #収集定義ファイルレコード格納領域
    gcd_cTmpRec=""                          #一時領域
    gcd_cTmpOne=""                          #一時領域（一文字）
    set -A gcd_cColDat                      #収集定義情報格納領域（配列形式）

    #収集定義ファイルの存在チェック
    if [ ! -f "$1" ]
      #収集定義ファイルが存在しない場合
      then
        #異常終了
        return "${ERROR_FLG}"
    fi

    #収集定義情報の取得
    #  1レコード:収集構成定義格納先
    #  2レコード:収集結果格納先
    #  3レコード:サーバ区分
    #収集定義ファイルのレコードが終了するまで読込む
    while read gcd_cColDatRec > "${DEV_NULL}" 2>&1
      do
        #前後空白削除
        gcd_cTmpRec=`echo "${gcd_cColDatRec}"`

        #空白行は読み飛ばす
        if [ "" = "${gcd_cTmpRec}" ]
          then
            continue
        fi

        #1文字取得
        gcd_cTmpOne=`echo "${gcd_cTmpRec}" | cut '-c1-1'`

        #一文字目が"#"の行は読み飛ばす
        if [ "#" = "${gcd_cTmpOne}" ]
          then
            continue
        fi

        #レコード内容を収集定義情報格納領域に格納
        gcd_cColDat[$gcd_iCnt]=`echo "${gcd_cTmpRec}"`

        #カウンタの加算
        gcd_iCnt=$((${gcd_iCnt} + 1))
      done < "$1"

    #取得レコード数チェック
    if [ "${COL_REC_KSU}" -ne "${#gcd_cColDat[*]}" ]
      #取得レコード数（項目数）が正しくない場合
      then
        #異常終了
        return "${ERROR_FLG}"
    fi

    #収集構成定義格納先の存在チェック
    if [ ! -d "${gcd_cColDat[$COL_DEF]}" ]
      #収集構成定義格納先が存在しない場合
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #サーバ区分のチェック
    if [ "${SVR_MGR}" != "${gcd_cColDat[$COL_SVR]}" -a \
         "${SVR_COL}" != "${gcd_cColDat[$COL_SVR]}" ]
      #サーバ区分が監理サーバ、収集サーバ以外の場合
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #収集サーバの場合はmountされていないため収集処理結果格納先
    #のチェックを実施できないため注意

    #サーバ区分が監理サーバの場合
    if [ "${SVR_MGR}" = "${gcd_cColDat[$COL_SVR]}" ]
      then
        #収集処理結果格納先の存在チェック
        if [ ! -d "${gcd_cColDat[$COL_RES]}" ]
          #収集処理結果格納先が存在しない場合
          then
            #異常終了
            return ${ERROR_FLG}
        fi
    fi

    #リトライ期間のチェック
    isNumeric "${gcd_cColDat[$COL_RET]}"
    if [ "${NORMAL_FLG}" != $? ]
      #数値以外の場合
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #収集定義情報の出力
    echo "${gcd_cColDat[*]}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : isNumeric
#  Description       : 数値チェック処理
#  Inputs            : $1         :チェック対象文字列
#  Outputs           : なし
#  Return            : NORMAL_FLG :数値
#                    : ERROR_FLG  :非数値
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            : 
######################################<->#######################################
isNumeric ()
{

echo_proc " -- 数値チェック処理 -- "

    in_iCnt=0                               #カウンタ
    in_cDiv=""                              #分割文字列
    in_cChar=""                             #チェック対象文字列

    #チェック対象文字列取得(前後空白の削除も実施)
    in_cChar=`echo "$1"`

    #チェック対象文字列長チェック
    if [ "${CHECK_0}" -ge "${#in_cChar}" ]
      #チェック対象文字列長が０以下の場合
      then
        #非数値
        return ${ERROR_FLG}
    fi

    #数値チェック
    in_cCnt=1
    while [ "${in_cCnt}" -le "${#in_cChar}" ]
      do
        #チェック対象文字の取得
        in_cDiv=`echo "${in_cChar}" | cut -c"${in_cCnt}"-"${in_cCnt}"`

        #数値であるかをチェックする
        if [ "${in_cDiv}" != "0" -a "${in_cDiv}" != "1" -a \
             "${in_cDiv}" != "2" -a "${in_cDiv}" != "3" -a \
             "${in_cDiv}" != "4" -a "${in_cDiv}" != "5" -a \
             "${in_cDiv}" != "6" -a "${in_cDiv}" != "7" -a \
             "${in_cDiv}" != "8" -a "${in_cDiv}" != "9"     ]
          #数値ない場合
          then
            #非数値
            return ${NORMAL_FLG}
        fi

        #カウンタ加算
        in_cCnt=$((${in_cCnt} + 1))
      done

    #数値
    return ${NORMAL_FLG}

}


# 収集定義情報取得処理-End


# 引数取得処理-Start

######################################<->#######################################
#  Name              : getParam
#  Description       : 引数取得処理
#  Inputs            : $1         :収集種別
#  Outputs           : 収集種別
#  Return            : NORMAL_FLG :正常終了
#                    : ERROR_FLG  :異常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getParam ()
{

echo_proc " -- 引数取得処理 -- "


    #引数の件数チェック
    if [ "$#" -ne 1 ] && [ "$#" -ne 2 ]
      #引数の指定が1～2件以外の場合
      then
        #異常終了(チェックエラー)
        return ${ERROR_FLG}
    elif [ "$#" -eq 2 ] && [ $2 -gt $CNS_YMD ]
      then
        #異常終了(チェックエラー)
        return ${ERROR_FLG}
    fi

    #収集種別の出力
    echo "$1"

    #正常終了
    return ${NORMAL_FLG}

}

# 引数取得処理処理-End


# 収集処理-Start

######################################<->#######################################
#  Name              : transactionCollectData
#  Description       : 収集処理
#  Inputs            : $1                   :収集種別
#                    : $2                   :収集構成定義格納先
#                    : $3                   :収集結果格納先
#                    : $4                   :リトライ期間
#  Outputs           : なし
#  Return            : NORMAL_FLG           :正常終了
#                    : ERROR_FLG            :異常終了
#                    : COL_ERROR_FLG        :収集エラー
#  Procedures Called : deleteCollectResult  :収集結果削除処理
#                    : getLastTransactionYMD:前回処理日取得処理
#                    : getTargetDay         :収集対象日取得処理
#                    : createCollectCmpData :収集構成定義情報作成処理
#                    : getReTargetDay       :再収集対象日取得処理
#                    : outReTargetData      :再収集情報出力処理
#                    : getTargetDayData     :収集対象日情報取得処理
#                    : getTargetLogfile     :ログファイル取得処理
#                    : outTraceLog          :トレースログ出力処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
transactionCollectData ()
{

echo_proc " -- 収集処理 -- "

    tcd_iCnt=0                              #カウンタ
    tcd_iPrcStatus=${NORMAL_FLG}            #処理結果（内部関数）
    tcd_iRetStatus=${NORMAL_FLG}            #処理結果
    tcd_cLastYMD=""                         #前回の処理日
    set -A tcd_cTargetDay                   #収集対象日（配列形式）
    set -A tcd_cReTargetDay                 #再収集対象日（配列形式）
    set -A tcd_cTargetDayData               #収集対象日情報（配列形式）
    set -A tcd_cColCmp                      #収集構成定義情報（配列形式）

    #収集構成定義情報作成処理
    createCollectCmpData "$2/${FILE_YICCODEF}"

    #処理結果判定
    if [ "${NORMAL_FLG}" != "$?" ]
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #収集結果削除処理
    deleteCollectResult "$1" "$3"

    #実行日手動指定判定 ## DATE:2022/10/14
    if [ ${#} = 5 ]; then
        #前回処理日取得処理
        tcd_cLastYMD=$(date -d "${5} 1 day ago" +%Y%m%d)

        #収集対象日取得処理
        set -A tcd_cTargetDay "${5}"
    else
        #前回処理日取得処理
        tcd_cLastYMD=`getLastTransactionYMD "$1" "$3"`

        #収集対象日取得処理
        set -A tcd_cTargetDay `getTargetDay "${tcd_cLastYMD}"`
    fi

    #収集対象日と再収集情報ファイルから収集処理の実行条件を確認する
    if [ "${CHECK_0}" -ge "${#tcd_cTargetDay[*]}" -a \
         ! -f "$3/${FILE_YICAGN}" ]
      #収集対象日が0日かつ、再収集情報ファイルが存在しない場合
      then
        #正常終了
        return ${NORMAL_FLG}
    fi

    #収集構成定義情報の件数分、処理を実施する
    while [ "${tcd_iCnt}" -lt "${iCmpKsu_}" ]
      do
        #再収集対象日取得処理
        set -A tcd_cReTargetDay `getReTargetDay \
                                "$3/${FILE_YICAGN}" "${cCmpSvr_[$tcd_iCnt]}" \
                                "${cCmpLogSbt_[$tcd_iCnt]}" \
                                "${cCmpSvrJp_[$tcd_iCnt]}"`

        #現在のレコードが収集対象のものかを確認する
        if [ "$1" != "${cCmpColSbt_[$tcd_iCnt]}" ]
          #収集種別が引数の収集種別と一致しない場合
          #↑収集対象外のセキュリティログ
          then
            #再収集情報を作業領域の再収集情報ファイルに出力する
            outReTargetData "${cWrkDir_}/${FILE_YICAGN}" \
                            "${cCmpSvr_[$tcd_iCnt]}" \
                            "${cCmpLogSbt_[$tcd_iCnt]}" \
                            "${tcd_cReTargetDay[*]}" \
                            "${cCmpSvrJp_[$tcd_iCnt]}"

            #カウンタの増加
            tcd_iCnt=$((${tcd_iCnt} + 1))

            #収集対象外のセキュリティログのため処理を飛ばす
            continue
        fi

        #収集対象日情報取得処理
        set -A tcd_cTargetDayData `getTargetDayData \
                                  "${cCmpBgnYMD_[$tcd_iCnt]}" \
                                  "${tcd_cTargetDay[*]}" \
                                  "${tcd_cReTargetDay[*]}"`

        #収集対象日情報の内容確認
        if [ "${CHECK_0}" -ge "${#tcd_cTargetDayData[*]}" ]
          #収集対象日内の日付の件数が０件以下の場合
          then
            #カウンタの増加
            tcd_iCnt=$((${tcd_iCnt} + 1))

            #収集対象外のセキュリティログのため処理を飛ばす
            continue
        fi

        #ログファイルの取得方法の変更により修正（2003/11/21）
        #ログファイル取得処理
        #getTargetLogfile "$3/${DIR_TEMP_AREA}" "$3/${FILE_YICRES}" \
        #                 "${cWrkDir_}/${FILE_YICAGN}" \
        #                 "${tcd_cTargetDayData[*]}" "${cCmpSvr_[$tcd_iCnt]}" \
        #                 "${cCmpSvrJp_[$tcd_iCnt]}" "${cCmpLogSbt_[$tcd_iCnt]}" \
        #                 "${cCmpLogDir_[$tcd_iCnt]}" "${cCmpLogNam_[$tcd_iCnt]}"

        #ログファイル取得処理
        getTargetLogfile "$3/${DIR_TEMP_AREA}" "$3/${FILE_YICRES}" \
                         "${cWrkDir_}/${FILE_YICAGN}" "${tcd_cTargetDayData[*]}" \
                         "${tcd_iCnt}" "$4" "${#tcd_cTargetDay[*]}"

        #ログファイル取得処理の処理結果判定
        tcd_iPrcStatus=$?
        if [ "${NORMAL_FLG}" != "${tcd_iPrcStatus}" ]
          #処理結果が正常終了以外の場合
          then
            #エラーフラグに収集エラーを格納
            tcd_iRetStatus=${COL_ERROR_FLG}
        fi

        #カウンタの増加
        tcd_iCnt=$((${tcd_iCnt} + 1))
      done

    #再収集情報ファイルの存在チェック
    #収集構成定義情報が取得できなかった場合は、再収集情報ファイルは
    #削除されたままとなる
    if [ -f "$3/${FILE_YICAGN}" ]
      #再収集情報ファイルが存在する場合
      then
        #再収集情報ファイルを削除する
        rm "$3/${FILE_YICAGN}" > "${DEV_NULL}" 2>&1
    fi

    #作業領域の再収集情報ファイルの存在チェック
    if [ -f "${cWrkDir_}/${FILE_YICAGN}" ]
      #作業領域の再収集情報ファイルが存在する場合
      then
        #作業領域の再収集情報ファイルを再収集情報ファイルとする
        mv "${cWrkDir_}/${FILE_YICAGN}" "$3/${FILE_YICAGN}" \
           > "${DEV_NULL}" 2>&1
    fi

    #処理結果の返却
    #  ０      ：正常終了
    #  ２      ：収集エラー有り
    #  上記以外：異常終了（収集構成定義情報エラーの場合）
    return ${tcd_iRetStatus}


}

######################################<->#######################################
#  Name              : createCollectCmpData
#  Description       : 収集構成定義情報作成処理
#  Inputs            : $1         :収集構成定義ファイル
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#                    : ERROR_FLG  :異常終了
#  Procedures Called : chkYMD     :日付妥当性チェック処理
#                    : chkLogSbt  :ログ種別妥当性チェック処理
#  Date              : 2003.10.11
#  Update            : 
######################################<->#######################################
createCollectCmpData ()
{

echo_proc " -- 収集構成定義情報作成処理 -- "

    cccd_iCnt=0                             #カウンタ
    cccd_iKmkKsu=0                          #収集構成定義項目件数
    cccd_iRetSts=${NORMAL_FLG}              #処理結果
    cccd_cRec=""                            #収集構成定義ファイルレコード
    cccd_cSvr=""                            #サーバ（サーバ名）
    cccd_cSvrJp=""                          #サーバ（日本語名）
    cccd_cSvrIP=""                          #サーバ（IPアドレス）
    cccd_cBgnYMD=""                         #運用開始日
    cccd_cColSbt=""                         #収集種別
    cccd_cLogSbt=""                         #ログファイル種類
    cccd_cLogDir=""                         #ログファイル格納先
    cccd_cLogNam=""                         #ログファイル名コンベンション
    cccd_cTmpOne=""                         #一時領域
    cccd_iFlg=${NORMAL_FLG}                 #エラーフラグ

    #収集構成定義情報初期化
    iCmpKsu_=0                              #収集構成定義情報件数
    set -A cCmpSvr_                         #サーバ（サーバ名）
    set -A cCmpSvrJp_                       #サーバ（日本語名）
    set -A cCmpSvrIP_                       #サーバ（IPアドレス）
    set -A cCmpBgnYMD_                      #運用開始日
    set -A cCmpColSbt_                      #収集種別
    set -A cCmpLogSbt_                      #ログファイル種類
    set -A cCmpLogDir_                      #ログファイル格納先
    set -A cCmpLogNam_                      #ログファイル名コンベンション

    #収集構成定義ファイルの存在チェック
    if [ ! -f "$1" ]
      #収集構成定義ファイルが存在しない場合
      then
        #収集構成定義無しのトレースログを出力する
        outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_007}"
        #正常終了
        return ${ERROR_FLG}
    fi

    #収集構成定義ファイルのレコード件数分、処理を実施
    while read cccd_cRec > "${DEV_NULL}" 2>&1
      do
        #前後空白削除
        cccd_cRec=`echo "${cccd_cRec}"`
        #空白行は読み飛ばす
        if [ "" = "${cccd_cRec}" ]
          then
            continue
        fi

        #1文字取得
        cccd_cTmpOne=`echo "${cccd_cRec}" | cut '-c1-1'`
        #一文字目が"#"の行は読み飛ばす
        if [ "#" = "${cccd_cTmpOne}" ]
          then
            continue
        fi

        #エラーフラグに正常を設定
        cccd_iFlg=${NORMAL_FLG} 

        #収集構成定義ファイルの項目数のチェック
        cccd_iKmkKsu=`echo "${cccd_cRec}" | awk '{print NF}'`
        #サーバ（サーバ名）の取得
        cccd_cSvr=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_SVR} + 1))'}'`
        #サーバ（日本語名）の取得
        cccd_cSvrJp=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_SVR_JP} + 1))'}'`
        #サーバ（IPアドレス）の取得
        cccd_cSvrIP=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_SVR_IP} + 1))'}'`
        #運用開始日の取得
        cccd_cBgnYMD=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_BGN_YMD} + 1))'}'`
        #ログファイル種類の取得
        cccd_cLogSbt=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_LOG_SBT} + 1))'}'`
        #ログファイル格納先の取得
        cccd_cLogDir=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_LOG_DIR} + 1))'}'`
        #ログファイル名コンベンションの取得
        cccd_cLogNam=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_LOG_FILE} + 1))'}'`
        #収集種別の取得
        cccd_cColSbt=`echo "${cccd_cRec}" | awk '{print $'$((${CMP_COL_SBT} + 1))'}'`

        #項目数チェック
        if [ "${CMP_KMK_KSU}" -ne "${cccd_iKmkKsu}" ]
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #サーバ（サーバ名）分割(2003/12/25追加)
        cccd_cSvrBgn="`echo "${cccd_cSvr}" | awk -F"_" '{print $1}'`"
        cccd_cSvrEnd="`echo "${cccd_cSvr}" | awk -F"_" '{print $2}'`"
        cccd_cSvrCnt="`echo "${cccd_cSvr}" | awk -F"_" '{print NF}'`"

        #アンダーバー数チェック
        if [ "${cccd_cSvrCnt}" -ne "2" ]
          #ホスト名＋"_*"以外の場合
          then
            #チェックエラー
            cccd_iFlg=${ERROR_FLG}
        fi

        #ホスト名（_以前）規定外文字列混在チェック（英小文字、数値、"-"のみ）
        echo "${cccd_cSvrBgn}" | grep -v "[^0-9a-z\\-]" > "${DEV_NULL}" 2>&1
        if [ "${NORMAL_FLG}" != "$?" ]
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #ホスト名（_以降）規定外文字列混在チェック（英小文字、数値、"-"のみ）
        echo "${cccd_cSvrEnd}" | grep -v "[^0-9a-z\\-]" > "${DEV_NULL}" 2>&1
        if [ "${NORMAL_FLG}" != "$?" ]
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #日付チェック
        chkYMD "${cccd_cBgnYMD}"
        if [ "${NORMAL_FLG}" != "$?" ]
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #ログファイル種類妥当性チェックチェック
        chkLogSbt "${cccd_cLogSbt}"
        if [ "${NORMAL_FLG}" != "$?" ]
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #構成定義の重複チェック方法を修正（11/27)
        #構成定義の重複チェック
        #gccd_iKsu=`grep "^${cccd_cSvr}" "$1" 2> "${DEV_NULL}" | \
        #           awk '{print $'$((${CMP_LOG_SBT} + 1))'}' 2> "${DEV_NULL}" | \
        #           grep "${cccd_cLogSbt}" 2> "${DEV_NULL}" | \
        #           wc -l 2> "${DEV_NULL}" | awk '{print $1}' 2> "${DEV_NULL}"`

        #サーバ名とログファイル種類単位に重複するレコードの存在チェック
        gccd_iKsu=`awk '
                    BEGIN {cSver = "'${cccd_cSvr}'";cLogSbt = "'${cccd_cLogSbt}'";iCnt = 0 }
                          {
                            if ( cSver == $'$((${CMP_SVR} + 1))' && cLogSbt == $'$((${CMP_LOG_SBT} + 1))' ){
                                iCnt++;
                            }
                          }
                    END   {print iCnt}' "$1"`

        #サーバ名、ログファイル種類が同一のレコードが存在するかをチェックする
        if [ "${CHECK_1}" -lt "${gccd_iKsu}" ]
          #2件以上存在する場合
          then
            cccd_iFlg=${ERROR_FLG}
        fi

        #エラーチェック
        if [ "${NORMAL_FLG}" = "${cccd_iFlg}" ]
          then
            #収集構成定義情報格納領域に格納する
            cCmpSvr_[cccd_iCnt]=${cccd_cSvr}
            cCmpSvrJp_[cccd_iCnt]=${cccd_cSvrJp}
            cCmpSvrIP_[cccd_iCnt]=${cccd_cSvrIP}
            cCmpBgnYMD_[cccd_iCnt]=${cccd_cBgnYMD}
            cCmpColSbt_[cccd_iCnt]=${cccd_cColSbt}
            cCmpLogSbt_[cccd_iCnt]=${cccd_cLogSbt}
            cCmpLogDir_[cccd_iCnt]=${cccd_cLogDir}
            cCmpLogNam_[cccd_iCnt]=${cccd_cLogNam}

            #収集構成定義情報件数を加算
            iCmpKsu_=$((${iCmpKsu_} + 1))

            #カウンタを加算
            cccd_iCnt=$((${cccd_iCnt} + 1))         
          else
            #収集構成定義情報エラーのトレースログを出力する
            outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_008} ${cccd_cRec}"
            cccd_iRetSts=${ERROR_FLG}
        fi
      done < "$1"

    #処理結果返却
    # 0:収集構成定義情報正常取得
    # 1:収集構成定義情報取得エラー
    return ${cccd_iRetSts}

}


######################################<->#######################################
#  Name              : chkYMD
#  Description       : 日付妥当性チェック処理("YYYYMMDD"形式)
#  Inputs            : $1        :日付
#  Outputs           : なし
#  Return            : NORMAL_FLG:正常終了
#                    : ERROR_FLG :異常終了
#  Procedures Called : chkLeap   :閏年判定処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
chkYMD ()
{

echo_proc " -- 日付妥当性チェック処理 -- "

    cy_iYY=0                                #年
    cy_iMM=0                                #月
    cy_iDD=0                                #日
    cy_iLeap=0                              #閏年判定フラグ
    cy_iDDLen=0                             #日付範囲
    set -A  cy_iMonth_Days                  #月-日付関連配列


    #日付の形式チェック
    case "$1" in
      #YYYYMMDD形式チェック（数字形式であることも確認する）
      ${YMD_TYPE})
        #YYYYMMDD形式のため処理続行
        ;;
      *)
        #YYYYMMDD形式以外のため異常終了
        return ${ERROR_FLG}
        ;;
    esac

    #年妥当性チェック
    #年月日取得
    cy_iYY=`echo "$1" | cut -c1-4`
    cy_iMM=`echo "$1" | cut -c5-6`
    cy_iDD=`echo "$1" | cut -c7-8`
    
    #月範囲チェック
    if [ "${MM_01}" -gt "${cy_iMM}" -o "${MM_12}" -lt "${cy_iMM}" ]
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #月-日関連配列取得
    set -A cy_iMonth_Days ${MONTH_DAYS}

    #日範囲取得
    cy_iDDLen=${cy_iMonth_Days[$((${cy_iMM} - 1))]}

    #閏年判定
    if [ "${MM_02}" -eq "${cy_iMM}" ]
      then
        #２月の場合
        #閏年チェック
        chkLeap "${cy_iYY}"
        cy_iLeap=$?
        if [ "${CHECK_LEAP}" = "${cy_iLeap}" ]
          then
            #閏年の場合
            cy_iDDLen=$((${cy_iDDLen} + 1))
        fi
    fi

    #日範囲チェック
    if [ "${CHECK_1}" -gt "${cy_iDD}" -o "${cy_iDDLen}" -lt "${cy_iDD}" ]
      then
        #異常
        return ${ERROR_FLG}
    fi

    #正常
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : chkLeap
#  Description       : 閏年判定処理("YYYYMMDD"形式)
#  Inputs            : $1            :日付(YYYY形式)
#  Outputs           : なし
#  Return            : CHECK_LEAP    :閏年
#                    : CHECK_NOT_LEAP:閏年以外
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
chkLeap ()
{

echo_proc " -- 閏年判定処理 -- "

    cl_cYY=0                                #日付(YYYY形式)

    #日付取得
    cl_cYY=$1

    #閏年チェック
    #4で割り切れるかをチェック
    if [ "${CHECK_0}" -eq "$((${cl_cYY} % 4))" ]
      then
        #100で割り切れるかをチェック
        if [ "${CHECK_0}" -eq "$((${cl_cYY} % 100))" ]
          then
            #400で割り切れるかをチェック
            if [ "${CHECK_0}" -eq "$((${cl_cYY} % 400))" ]
              then
                #閏年
                return ${CHECK_LEAP}
              else
                #閏年以外
                return ${CHECK_NOT_LEAP}
            fi
          else
            #閏年
            return ${CHECK_LEAP}
        fi
    fi

    #閏年以外
    return ${CHECK_NOT_LEAP}

}


######################################<->#######################################
#  Name              : chkLogSbt
#  Description       : ログ種別妥当性チェック処理
#  Inputs            : $1            :ログ種別（'N','A','O','E'）
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#                    : ERROR_FLG  :異常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
chkLogSbt ()
{

echo_proc " -- ログ種別妥当性チェック処理 -- "

    #ログ種別チェック 2004.08.05 判定項目追加
    if [ "${LOG_SBT_N}" != "$1" -a "${LOG_SBT_A}" != "$1" -a "${LOG_SBT_O}" != "$1" -a \
         "${LOG_SBT_E}" != "$1" -a "${LOG_SBT_C}" != "$1" -a "${LOG_SBT_T}" != "$1"   ]
      #'N','A','O','E','C','T'以外の場合
      then
        #異常終了
        return ${ERROR_FLG}
    fi

    #正常終了
    return ${NORMAL_FLG}

}

######################################<->#######################################
#  Name              : deleteCollectResult
#  Description       : 収集結果削除処理
#  Inputs            : $1         :収集種別
#                    : $2         :収集結果格納先
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
deleteCollectResult ()
{

echo_proc " -- 収集結果削除処理 -- "

    #11/10の仕様変更にて収集結果は無条件で削除することに決定
    #dcr_iRet=${NORMAL_FLG}                 #処理結果

    #収集処理稼動結果ファイルの存在チェック
    #if [ ! -f "$2/${FILE_YICTRRES}" ]
    #  #収集処理稼動結果ファイルが存在しない場合
    #  then
    #   #正常終了
    #   return "${NORMAL_FLG}"
    #fi

    #前回の処理結果の取得
    #  収集処理稼動結果ファイルから処理日と処理時間が最も新しいものの処理結果を
    #  取得する。
    #dcr_iRet=`awk -F"${KGI_PGM}" '
    #           BEGIN {
    #                   #変数の初期化
    #                   cYMD = "";cHMS = "";cRet = "";
    #           }
    #           {
    #                   #処理日のチェック
    #                   if ( ( cYMD < $2 ) || ( cYMD == $2 && cHMS < $3) ){
    #                       #最新のレコードの場合は、日付、時間、処理結果を取得
    #                       cYMD1 = $2;cHMS2 = $3;cRet3 = $4;
    #                   }
    #           }
    #           END {
    #                   #処理結果を出力
    #                   print cRet
    #           }' "$2/${FILE_YICTRRES}"`

    #前回の処理結果の確認
    #if [ "${NORMAL_FLG}"    != "${dcr_iRet}" -a \
    #     "${COL_ERROR_FLG}" != "${dcr_iRet}" ]
    #  #処理結果が正常終了、収集エラー以外の場合
    #  #↑ボリュームコピーエラーまたは異常終了の場合となる
    #  then
    #   #正常終了
    #   return ${NORMAL_FLG}
    #fi

    #収集結果ファイルの削除
    if [ -f "$2/${FILE_YICRES}" ]
      #収集結果ファイルが存在する場合
      then
        #収集結果ファイルの削除
        rm "$2/${FILE_YICRES}" > "${DEV_NULL}" 2>&1
    fi

    #一時領域の削除
    if [ -d "$2/${DIR_TEMP_AREA}" ]
      #一時領域が存在する場合
      then
        #一時領域下にはディレクトリやファイルも多数存在するため"-r"オプションを
        #指定し、一時領域を削除する（実行には十分に注意すること）
        rm -r "$2/${DIR_TEMP_AREA}" > "${DEV_NULL}" 2>&1
    fi

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : getLastTransactionYMD
#  Description       : 前回処理日取得処理
#  Inputs            : $1         :収集種別
#                    : $2         :収集結果格納先
#  Outputs           : 前回処理日（YYYYMMDD形式）
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : subYMD     :日付減算処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getLastTransactionYMD ()
{

echo_proc " -- 前回処理日取得処理 -- "

    glty_iRet=""                            #処理結果
    glty_cPrvYMD=""                         #前回処理日
    glty_cPrvYMD2=""                        #前回処理日２

    #収集処理稼動結果ファイルの存在チェック
    if [ ! -f "$2/${FILE_YICTRRES}" ]
      #収集処理稼動結果ファイルが存在しない場合
      then
        #現在処理日の前日を出力
        glty_cPrvYMD=`subYMD "${CNS_YMD}" "1"`
        echo "${glty_cPrvYMD}"

        #正常終了
        return ${NORMAL_FLG}
    fi

    #前回の処理日の取得
    #  収集処理稼動結果ファイルから収集種別が一致するレコードのうち処理日と
    #  処理時間が最も新しいものを取得する。
    #  処理結果が異常終了のものは無視する
    glty_cPrvYMD=`awk -F"${KGI_PGM}" '
                BEGIN {
                        #変数の初期化
                        cYMD = "";cHMS = "";cColSbt = "'$1'";cRet = "'${ERROR_FLG}'"
                }
                {
                        #収集種別と処理結果のチェック
                        if ( ( cColSbt == $1 && cRet != $4 )){
                        #収集種別が一致し、処理結果が異常終了以外の場合
                            #処理日のチェック
                            if ( ( cYMD < $2 ) || ( cYMD == $2 && cHMS < $3) ){
                                #最新のレコードの場合は、日付、時間を取得
                                cYMD = $2;cHMS = $3;
                            }
                        }
                }
                END {
                        #処理日を出力
                        print cYMD
                }' "$2/${FILE_YICTRRES}"`

    #前回の処理日の取得
    #  収集処理稼動結果ファイルから収集種別が一致するレコードのうち処理日と
    #  処理時間が最も新しいものを取得する。
    #  処理結果が異常終了の最も古い日付を取得する
    glty_cPrvYMD2=`awk -F"${KGI_PGM}" '
                BEGIN {
                        #変数の初期化
                        cYMD = "99999999";cHMS = "999999";cColSbt = "'$1'";
                        cRet = "'${ERROR_FLG}'"
                }
                {
                        #収集種別と処理結果のチェック
                        if ( ( cColSbt == $1  && cRet == $4 )){
                        #収集種別が一致する場合
                            #処理日のチェック
                            if ( ( cYMD > $2 ) || ( cYMD == $2 && cHMS > $3) ){
                                #最新のレコードの場合は、日付、時間を取得
                                cYMD = $2;cHMS = $3;
                            }
                        }
                }
                END {
                        #処理日を出力
                        print cYMD
                }' "$2/${FILE_YICTRRES}"`

    #処理日の確認
    if [ "" = "`echo "${glty_cPrvYMD}"`" ]
      #処理日が取得できなかった場合
      then
        #異常終了の日付を確認
        if [ "" = "`echo "${glty_cPrvYMD2}"`" ]
          then
            #現在処理日の前日を取得
            glty_cPrvYMD=`subYMD "${CNS_YMD}" "1"`
          else
            #異常終了の日付の前日を取得
            glty_cPrvYMD=`subYMD "${glty_cPrvYMD2}" "1"`
        fi
    fi

    #前回処理日を出力
    echo "${glty_cPrvYMD}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : subYMD
#  Description       : 日付減算処理
#  Inputs            : $1        :日付(YYYYMMDD形式)
#                    : $2        :減算日数
#  Outputs           : 標準出力  :日付(YYYYMMDD形式)
#  Return            : NORMAL_FLG:正常
#  Procedures Called : chkLeap   :閏年チェック処理
#                    : editNumber:数値-文字列編集処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
subYMD ()
{

echo_proc " -- 日付減算処理 -- "

    sy_iYMD=0                               #日付
    sy_iSub=0                               #減算日
    sy_iYY=0                                #年
    sy_iMM=0                                #月
    sy_iDD=0                                #日
    sy_iDDLen=0                             #該当月日付
    sy_iDDLenNxt=0                          #該当次月日付
    sy_iLeap=0                              #閏年判定フラグ
    sy_iYMD=0                               #日付加算結果
    set -A sy_iMonth_Days                   #月-日関連配列


    #日付取得
    sy_iYMD=$1

    #減算日取得
    sy_iSub=$2

    #年、月、日取得
    sy_iYY=`echo "${sy_iYMD}" | cut -c1-4`
    sy_iMM=`echo "${sy_iYMD}" | cut -c5-6`
    sy_iDD=`echo "${sy_iYMD}" | cut -c7-8`

    #月-日関連配列取得
    set -A sy_iMonth_Days ${MONTH_DAYS}

    #閏年チェック
    chkLeap "${sy_iYY}"
    sy_iLeap=$?

    #日付減算
    while [ "${sy_iDD}" -le "${sy_iSub}" ]
      do
        #減算日から日を減算する
        sy_iSub=$((${sy_iSub} - ${sy_iDD}))

        #月から1減算する
        sy_iMM=$((${sy_iMM} - 1))

        #月範囲チェック
        if [ "${MM_01}" -gt "${sy_iMM}" ]
          #月が１未満の場合
          then
            #年から1減算する
            sy_iYY=$((${sy_iYY} - 1))

            #月を12にする
            sy_iMM=${MM_12}

            #閏年チェック
            chkLeap "${sy_iYY}"
            sy_iLeap=$?
        fi

        if [ "${MM_01}" -gt "${sy_iMM}" ]
          #月が１以下の場合
          then
            #12月の月を取得する
            sy_iDDLen=${sy_iMonth_Days[$MM_12]}
          else
            sy_iDDLen=${sy_iMonth_Days[$((${sy_iMM} - 1))]}
            #2月チェック
            if [ "${MM_02}" -eq "${sy_iMM}" -a "${CHECK_LEAP}" -eq "${sy_iLeap}" ]
              then
                #閏年の場合
                sy_iDDLen=$((${sy_iDDLen} + 1))
            fi
        fi
        #日を前月の最終日にする
        sy_iDD=${sy_iDDLen}
      done

    #日付から減算日を減算する
    sy_iDD=$((${sy_iDD} - ${sy_iSub}))

    #日付形式に編集して結果を出力する
    sy_cYMD=`editNumber "${sy_iYY}" "${YY_LEN}"`
    sy_cYMD="${sy_cYMD}`editNumber "${sy_iMM}" "${MM_LEN}"`"
    sy_cYMD="${sy_cYMD}`editNumber "${sy_iDD}" "${DD_LEN}"`"
    echo "${sy_cYMD}"

    #正常
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : editNumber
#  Description       : 数値-文字列編集処理
#  Inputs            : $1        :数値
#                    : $2        :文字列長
#  Outputs           : 標準出力  :編集結果文字列
#  Return            : NORMAL_FLG:正常
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
editNumber ()
{

echo_proc " -- 数値-文字列編集処理 -- "

    ey_cNum=""                              #数値
    ey_iLen=0                               #文字列長

    #数値・文字列長取得
    ey_cNum=$1
    ey_ciLen=$2

    #文字列長チェック
    if [ "${#ey_cNum}" -ge "${ey_ciLen}" ]
      then
        #結果出力
        echo "${ey_cNum}"
        #正常
        return ${NORMAL_FLG}
    fi

    #数値-文字列編集
    while [ "${#ey_cNum}" -lt "${ey_ciLen}" ]
      do
        #数値の初めに０を追加する
        ey_cNum="0${ey_cNum}"
      done

    #編集結果出力
    echo "${ey_cNum}"

    #正常
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : getTargetDay
#  Description       : 収集対象日取得処理
#  Inputs            : $1         :前回処理日
#  Outputs           : 収集対象日（YYYYMMDDの配列形式）
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : subYMD     :日付減算処理
#                    : addYMD     :日付加算処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getTargetDay ()
{

echo_proc " -- 収集対象日取得処理 -- "

    gtd_iCnt=0                              #カウンタ
    gtd_cTargetYMD=""                       #収集対象日付
    gtd_cBaseYMD=""                         #基準日付
    set -A gtd_cTargetDay                   #収集対象日（配列形式）

    #収集対象日付の初期化（前回処理日を設定）
    gtd_cTargetYMD=$1

    #基準日付の取得（現在の処理日の前日）
    gtd_cBaseYMD=`subYMD "${CNS_YMD}" "1"`

    #前回処理日から基準日付までの期間を取得する
    while [ "${gtd_cTargetYMD}" -le "${gtd_cBaseYMD}" ]
      do
        #収集対象日（配列形式）に収集対象日付を格納
        gtd_cTargetDay[$gtd_iCnt]=${gtd_cTargetYMD}

        #カウンタの増加
        gtd_iCnt=$((${gtd_iCnt} + 1))

        #収集対象日付を１日加算する
        gtd_cTargetYMD=`addYMD "${gtd_cTargetYMD}" "1"`
      done

    #収集対象日の出力
    echo "${gtd_cTargetDay[*]}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : addYMD
#  Description       : 日付加算処理
#  Inputs            : $1         :日付(YYYYMMDD形式)
#                    : $2         :加算日数
#  Outputs           : 標準出力   :日付(YYYYMMDD形式)
#  Return            : NORMAL_FLG :正常
#  Procedures Called : editNumber :数値-文字列編集処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
addYMD ()
{

echo_proc " -- 日付加算処理 -- "

    ay_iYMD=0                               #日付
    ay_iAdd=0                               #加算日
    ay_iYY=0                                #年
    ay_iMM=0                                #月
    ay_iDD=0                                #日
    ay_iDDLen=0                             #該当月日付
    ay_iDDLenNxt=0                          #該当次月日付
    ay_iLeap=0                              #閏年判定フラグ
    ay_iMonth_Days=0                        #月-日関連配列

    #日付取得
    ay_iYMD=$1

    #加算日取得
    ay_iAdd=$2

    #年、月、日取得
    ay_iYY=`echo "${ay_iYMD}" | cut -c1-4`
    ay_iMM=`echo "${ay_iYMD}" | cut -c5-6`
    ay_iDD=`echo "${ay_iYMD}" | cut -c7-8`

    #月-日関連配列取得
    set -A ay_iMonth_Days ${MONTH_DAYS}

    #日付加算
    ay_iDD=$((${ay_iDD} + ${ay_iAdd}))

    #該当月日付取得
    #1,3,5,7,8,10,12月-31日
    #4,6,9,11月-30日
    #2月-28日
    ay_iDDLen=${ay_iMonth_Days[$((${ay_iMM} - 1))]}

    #閏年チェック
    chkLeap ${ay_iYY}
    ay_iLeap=$?

    #2月チェック
    if [ "${MM_02}" -eq "${ay_iMM}" -a "${CHECK_LEAP}" -eq "${ay_iLeap}" ]
      then
        #閏年の場合
        ay_iDDLen=$((${ay_iDDLen} + 1))
    fi

    #年月日計算
    while [ "${ay_iDDLen}" -lt "${ay_iDD}" ]
      do
        #日から該当月の日範囲を減算
        ay_iDD=$((${ay_iDD} - ${ay_iDDLen}))

        #月加算
        ay_iMM=$((${ay_iMM} + 1))

        #月範囲チェック
        if [ "${MM_12}" -lt "${ay_iMM}" ]
          #月が12月を超過している場合
          then
            #年加算
            ay_iYY=$((${ay_iYY} + 1))
            #月初期化
            ay_iMM=${CHECK_1}
            #閏年チェック
            chkLeap ${ay_iYY}
            ay_iLeap=$?
        fi

        #該当月の日範囲を取得
        ay_iDDLen=${ay_iMonth_Days[$((${ay_iMM} - 1))]}

        #2月チェック
        if [ "${MM_02}" -eq "${ay_iMM}" -a "${CHECK_LEAP}" -eq "${ay_iLeap}" ]
          then
            #閏年の場合
            ay_iDDLen=$((${ay_iDDLen} + 1))
        fi

      done

    #日付形式に編集して結果を出力する
    ay_cYMD=`editNumber "${ay_iYY}" "${YY_LEN}"`
    ay_cYMD="${ay_cYMD}`editNumber "${ay_iMM}" "${MM_LEN}"`"
    ay_cYMD="${ay_cYMD}`editNumber "${ay_iDD}" "${DD_LEN}"`"
    echo "${ay_cYMD}"

    #正常
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : getReTargetDay
#  Description       : 再収集対象日取得処理
#  Inputs            : $1         :再収集情報ファイル
#                    : $2         :サーバ（サーバ名）
#                    : $3         :ログファイル種類（ログ種別）
#  Outputs           : 再収集対象日
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getReTargetDay ()
{

echo_proc " -- 再収集対象日取得処理 -- "

    grtd_iCnt=0                             #カウンタ
    grtd_cAgnRec=""                         #再収集情報ファイルレコード
    set -A grtd_cReTargetDay                #再収集対象日（配列形式）

    #再収集情報ファイルの存在チェック
    if [ ! -f "$1" ]
      #再収集情報ファイルが存在しない場合
      then
        #正常終了
        return ${NORMAL_FLG}
    fi

    #再収集情報ファイルの検索
    #  引数のサーバ、ログファイル種類に該当するレコードを検索
### 2005.03.28    grep "^$2,$3,.*" "$1" |&

    #検索結果の取得
    grep "^$2,$3,.*" "$1" | while read grtd_cAgnRec
      do
        #再収集対象日の取得
        grtd_cReTargetDay[$grtd_iCnt]=`echo "${grtd_cAgnRec}" | \
                                       awk -F"${KGI_PGM}" '{print $3}'`
        #カウンタの増加
        grtd_iCnt=$((${grtd_iCnt} + 1))
      done

    #再収集対象日の出力
    echo "${grtd_cReTargetDay[*]}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : outReTargetData
#  Description       : 再収集情報ファイル出力処理
#  Inputs            : $1         :再収集情報ファイル
#                    : $2         :サーバ（サーバ名）
#                    : $3         :ログファイル種類
#                    : $4         :再収集対象日（配列形式）
#                    : $5         :サーバ名（日本語名称）
#                    : $6         :FTP-GETPUTフラグ（ログ中継→ログ監理への送信エラーフラグ）
#                                  エラーでなければ空で入力
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
outReTargetData ()
{

echo_proc " -- 再収集情報ファイル出力処理 -- "

    ortd_cYMD=""                            #日付取得領域
    set -A ortd_cReTargetDay                #再収集対象日

    #引数の再収集対象日の取得
    set -A ortd_cReTargetDay $4

    #再収集対象日の件数分、再収集情報ファイルのレコードを出力する
    for ortd_cYMD in ${ortd_cReTargetDay[*]}
      do
        #再収集情報ファイルの出力
        #  $1:サーバ、ログファイル種類、再収集対象日
        #  区切り文字：","
        echo -e "$2${KGI_PGM}\c"                     >> "$1"
        echo -e "$3${KGI_PGM}\c"                     >> "$1"
        echo -e "${ortd_cYMD}${KGI_PGM}\c"           >> "$1"

       #FTPエラー時は固定文出力 
        if [ "${ERROR_FLG}" = "$6" ]
          then
           echo -e "$5${KGI_PGM}\c"                  >> "$1"
           echo -e "ログ中継サーバ FTP送信エラー（ログ監理サーバ連携）"             >> "$1"

          #エラーでなければサーバ名のみ出力
          else
           echo -e "$5"                              >> "$1"
 
          fi
      done

    #正常終了
    return ${NORMAL_FLAG}

}


######################################<->#######################################
#  Name              : getTargetDayData
#  Description       : 収集対象日情報取得処理
#  Inputs            : $1         :運用開始日
#                    : $2         :収集対象日（配列形式）
#                    : $3         :再収集対象日（配列形式）
#  Outputs           : 収集対象日情報
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getTargetDayData ()
{

echo_proc " -- 収集対象日情報取得処理 -- "

    gtdd_iCnt=0                             #カウンタ
    gtdd_cYMD=""                            #日付格納領域
    set -A gtdd_cYMDArray                   #収集対象日、再収集対象日格納領域
    set -A gtdd_cTargetDayData              #収集対象日情報（配列形式）

    #再収集対象日の方が前の日付で有る可能性が高いため、先行して格納する

    #再収集対象日の取得
    set -A gtdd_cYMDArray $3

    #収集対象日から運用開始日以降の日付を収集対象日情報に格納する
    for gtdd_cYMD in ${gtdd_cYMDArray[*]}
      do
        if [ "$1" -le "${gtdd_cYMD}" ]
          then

            #収集対象日と同一日のチェック
            echo "${gtdd_cTargetDayData[*]}" | \
            grep "${gtdd_cYMD}" > "${DEV_NULL}" 2>&1

            if [ "${NORMAL_FLG}" != "$?" ]
              #収集対象日に含まれていない場合
              then
                gtdd_cTargetDayData[$gtdd_iCnt]="${gtdd_cYMD}"
                gtdd_iCnt=$((${gtdd_iCnt} + 1))
            fi
        fi
      done

    #収集対象日の取得
    set -A gtdd_cYMDArray $2

    #収集対象日から運用開始日以降の日付を収集対象日情報に格納する
    for gtdd_cYMD in ${gtdd_cYMDArray[*]}
      do
        if [ "$1" -le "${gtdd_cYMD}" ]
          then

            #収集対象日と同一日のチェック
            echo "${gtdd_cTargetDayData[*]}" | \
            grep "${gtdd_cYMD}" > "${DEV_NULL}" 2>&1

            if [ "${NORMAL_FLG}" != "$?" ]
              #収集対象日に含まれていない場合
              then
                gtdd_cTargetDayData[$gtdd_iCnt]="${gtdd_cYMD}"
                gtdd_iCnt=$((${gtdd_iCnt} + 1))
            fi
        fi
      done

    #収集対象日情報の出力
    echo "${gtdd_cTargetDayData[*]}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : getTargetLogfile
#  Description       : ログファイル取得処理
#  Inputs            : $1               :一時領域
#                    : $2               :収集結果ファイル
#                    : $3               :再収集情報ファイル
#                    : $4               :収集対象日情報（配列形式）
#                    : $5               :収集構成定義情報インデックス
#                    : $6               :リトライ期間
#                    : $7               :収集対象日日数
#  Outputs           : なし
#  Return            : NORMAL_FLG       :正常終了
#                    : ERROR_FLG        :異常終了（ログファイル取得エラー発生）
#  Procedures Called : getLogSbtDir     :ログ種別ディレクトリ取得処理
#                    : cnvLogFileName   :ログファイル名変換処理
#                    : outTraceLog      :トレースログ出力処理
#                    : chkFtpResult     :FTP実行結果確認処理
#                    : chkReYMD         :リトライ期間チェック処理
#                    : outReTargetData  :再収集情報ファイル出力処理
#                    : outColResultData :収集結果ファイル出力処理
#  Date              : 2022.08.01
#  Update            : ログ中継サーバのNASマウント廃止の為、ログ監理サーバNAS内にログファイル送信する処理を追加
######################################<->#######################################
getTargetLogfile ()
{
filelist=""
fileSize=0

echo_proc " -- ログファイル取得処理 -- "

    gtlf_iErrFlg=${NORMAL_FLG}              #FTP-GETエラーフラグ
    gtlf_iFlg=${NORMAL_FLG}                 #エラーフラグ
    gtlf_cLog=""                            #ログファイル名
    gtlf_cDir=""                            #一時領域ディレクトリ
    gtlf_cLogSbtDir=""                      #ログ種別ディレクトリ
    gtlf_cDay=""                            #日付
    gtlf_iSts=""                            #ステータス
    set -A gtlf_cTargetDay                  #収集対象日情報(配列形式)
    set -A gtlf_cLogName                    #ログファイル名称

    #収集対象日情報の取得
    set -A gtlf_cTargetDay $4

    #ログ種別ディレクトリの取得
    gtlf_cLogSbtDir=`getLogSbtDir "${cCmpLogSbt_[$5]}"`

    #FTP-GET時のログ格納先ディレクトリの作成
    mkdir "${cWrkDir_}/${DIR_LOG}" > "${DEV_NULL}" 2>&1

    ### 2005.04.08 ADD
    if [ "4" = "${cCmpColSbt_[$tcd_iCnt]}" ];then

	### 自サーバＦＴＰ（ホストログ収集処理時）###
	FTP_USER="pyyiz001"                     #ユーザＩＤ
	FTP_PASS="pyyiz111"                     #パスワード

    else

	### 他業務サーバ用 FTPユーザＩＤ、パスワード
	FTP_USER="pyyiz001"                     #ユーザＩＤ
#	FTP_PASS="pyyiz!DMZ"                    #パスワード

        #テスト用にパスワード修正（自サーバ用）
        FTP_PASS="pyyiz111"                     #パスワード
    fi

    ##############################################
    FTPMODE_DEF="${DIR_CONF}/yicactdef.txt"

    grep ${cCmpSvrIP_[$5]} ${FTPMODE_DEF} > /dev/null 2>&1
    GetSTS=$?

    if [ "${NORMAL_FLG}" != "${GetSTS}" ];then
	### Passiveモード対応化 ###

        #FTP実行時の標準入力ファイル（実行内容）の作成
        #該当サーバへの接続（サーバ（IPアドレス）を使用する）
        echo "open ${cCmpSvrIP_[$5]}"            > "${cWrkDir_}/${FILE_FTP_ACT}"
        #ユーザＩＤ、パスワード入力
        echo "user ${FTP_USER} ${FTP_PASS}"     >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #ログ格納先ディレクトリへの移動
        echo "cd \"${cCmpLogDir_[$5]}\""            >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #ローカルホストの作業領域への移動
        echo "lcd ${cWrkDir_}/${DIR_LOG}"       >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #転送モードをバイナリモードに変更
        echo "binary"                           >> "${cWrkDir_}/${FILE_FTP_ACT}"
    else
	### Activeモード強制指定対応 ###

        #FTP実行時の標準入力ファイル（実行内容）の作成
        #該当サーバへの接続（サーバ（IPアドレス）を使用する）
        echo "open ${cCmpSvrIP_[$5]}"            > "${cWrkDir_}/${FILE_FTP_ACT}"
        #ユーザＩＤ、パスワード入力
        echo "user ${FTP_USER} ${FTP_PASS}"     >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #ログ格納先ディレクトリへの移動
        echo "cd \"${cCmpLogDir_[$5]}\""            >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #ローカルホストの作業領域への移動
        echo "lcd ${cWrkDir_}/${DIR_LOG}"       >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #転送モードをバイナリモードに変更
        echo "binary"                           >> "${cWrkDir_}/${FILE_FTP_ACT}"
        #passiveモードOFF指定(強制指定）
        echo "passive"                           >> "${cWrkDir_}/${FILE_FTP_ACT}"
    fi

echo_proc ${cCmpLogDir_[$5]}

    #収集対象日の件数分処理を実施
    for gtlf_cDay in ${gtlf_cTargetDay[*]}
      do
        #収集対象日のログファイル名称を取得する
        gtlf_cLog=`cnvLogFileName "${cCmpLogNam_[$5]}" "${gtlf_cDay}"`

        #ログファイル名から最初に「.」が現れるまでの名称を削除する（拡張子の削除）
        gtlf_cLog=${gtlf_cLog%%.*}

        #FTP-GET文の作成
        # 引数のログファイル格納先下からセキュリティログを取得しFTP-GET時のログ
        # 格納先ディレクトリに格納
        echo "mget ${gtlf_cLog}*"           >> "${cWrkDir_}/${FILE_FTP_ACT}"
      done

    #接続を閉じる
    echo "close" >> "${cWrkDir_}/${FILE_FTP_ACT}"

    #FTP終了
    echo "bye"   >> "${cWrkDir_}/${FILE_FTP_ACT}"

#   FTPの結果ファイルは作業領域の直下に作成したいのだが作業領域直下を指定すると
#   別のディレクトリに結果ファイルが格納されてしまうため、ログ格納先ディレクトリ
#   に格納している（原因不明）

    #FTP実行前の時間を記憶
    ftpStartTime=`date '+%s'`

    #FTP実行
    ftp < "${cWrkDir_}/${FILE_FTP_ACT}" > "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" 2>&1
cp ${cWrkDir_}/${FILE_FTP_ACT} /tmp/ftp.txt
cp ${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES} /tmp/ftp_res.txt


    #FTP実行時の時間を記憶
    ftpEndTime=`date '+%s'`

    #FTP実行結果確認処理
    chkFtpResult "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}"

    #処理結果確認
    if [ "${NORMAL_FLG}" != "$?" ]
      then
        #FTP-GETエラーフラグに異常を設定
        gtlf_iErrFlg=${ERROR_FLG}

        #FTP接続エラー時のトレースログを出力する
        outTraceLog "${TRACE_INFOM}" "${TRACE_ERROR_FLG}" \
                    "${TRACE_002} ${cCmpSvrJp_[$5]} ${cCmpLogSbt_[$5]}"
    fi

    #FTP実行時の標準入力ファイルの削除
    if [ -f "${cWrkDir_}/${FILE_FTP_ACT}" ]
      then
        rm "${cWrkDir_}/${FILE_FTP_ACT}" > "${DEV_NULL}" 2>&1
    fi

    #FTP結果ファイルの削除
    if [ -f "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" ]
      then
        rm "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" > "${DEV_NULL}" 2>&1
    fi

    #ログファイルの取得結果確認
    #収集対象日の件数分処理を実施


    for gtlf_cDay in ${gtlf_cTargetDay[*]}
      do
        #FTP-GETエラーフラグ確認
        if [ "${NORMAL_FLG}" != "${gtlf_iErrFlg}" ]
          #接続エラー、認証エラーの場合
          then
            #リトライ期間のチェック
            chkReYMD "${gtlf_cDay}" "$6" "$7"
            gtlf_iSts=$?
            if [ "${CHECK_RT_NORMAL}" = "${gtlf_iSts}" ]
              #リトライ期間内の場合
              then
                #収集結果を収集エラーとして収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_ERR}"

                #再収集情報を作業領域の再収集情報ファイルに出力する
                outReTargetData "$3" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                "${gtlf_cDay}" \
                                "${cCmpSvrJp_[$5]}"
            fi

            if [ "${CHECK_RT_EQUAL}" = "${gtlf_iSts}" ]
              #リトライ期限の場合
              then
                #収集結果を収集エラーとして収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_ERR}"

                #再収集情報を作業領域の再収集情報ファイルに出力する
                outReTargetData "$3" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                "${gtlf_cDay}" \
                                "${cCmpSvrJp_[$5]}"

                #セキュリティログ取得エラー時のトレースログを出力する
                outTraceLog "${TRACE_ERROR}" "${TRACE_ERROR_FLG}" \
                            "${TRACE_003} ${cCmpSvr_[$5]} ${cCmpLogSbt_[$5]} ${gtlf_cDay}"

                #エラーフラグに異常を設定
                gtlf_iFlg=${ERROR_FLG}
            fi

            if [ "${CHECK_RT_NORMAL}" != "${gtlf_iSts}" -a "${CHECK_RT_EQUAL}" != "${gtlf_iSts}" ]
              #リトライ期間以外の場合
              then
                #収集結果をセキュリティログ無として収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_NON}"
            fi

            #ログファイルは存在しないため次のログファイルの処理を実施
            continue
        fi

        #収集対象日のログファイル名称を取得する
        gtlf_cLog=`cnvLogFileName "${cCmpLogNam_[$5]}" "${gtlf_cDay}"`

        #ログファイル名から最初に「.」が現れるまでの名称を削除する（拡張子の削除）
        gtlf_cLog=${gtlf_cLog%%.*}

        #収集されたログファイル名の一覧を取得する
        set -A gtlf_cLogName `ls -l "${cWrkDir_}/${DIR_LOG}" | \
                              awk '/^-/{print $9}' | grep -i "^${gtlf_cLog}.*" | sort -k1`

        #収集されたログファイル名の件数チェック
        if [ "${CHECK_0}" -ge "${#gtlf_cLogName[*]}" ]
          #件数が０件の場合（ログファイル無しの場合）
          then
            #リトライ期間のチェック
            chkReYMD "${gtlf_cDay}" "$6" "$7"
            gtlf_iSts=$?
            if [ "${CHECK_RT_NORMAL}" = "${gtlf_iSts}" ]
              #リトライ期間内の場合
              then
                #収集結果を収集エラーとして収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_ERR}"

                #再収集情報を作業領域の再収集情報ファイルに出力する
                outReTargetData "$3" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                "${gtlf_cDay}" \
                                "${cCmpSvrJp_[$5]}"
            fi

            if [ "${CHECK_RT_EQUAL}" = "${gtlf_iSts}" ]
              #リトライ期限の場合
              then
                #収集結果を収集エラーとして収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_ERR}"

                #再収集情報を作業領域の再収集情報ファイルに出力する
                outReTargetData "$3" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                "${gtlf_cDay}" \
                                "${cCmpSvrJp_[$5]}"

                #セキュリティログ取得エラー時のトレースログを出力する
                outTraceLog "${TRACE_ERROR}" "${TRACE_ERROR_FLG}" \
                            "${TRACE_003} ${cCmpSvr_[$5]} ${cCmpLogSbt_[$5]} ${gtlf_cDay}"

                #エラーフラグに異常を設定
                gtlf_iFlg=${ERROR_FLG}
            fi

            if [ "${CHECK_RT_NORMAL}" != "${gtlf_iSts}" -a "${CHECK_RT_EQUAL}" != "${gtlf_iSts}" ]
              #リトライ期間以外の場合
              then
                #収集結果をセキュリティログ無として収集結果ファイルに出力する
                outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                                 "${gtlf_cDay}" "" "" "${COL_RES_NON}"
            fi

            #ログファイルは存在しないため次のログファイルの処理を実施
            continue
         fi

        #セキュリティログの一時領域での格納ディレクトリパスの作成
        #  →"/一時領域/収集対象日/サーバ(サーバ名)/ログ種別"
        gtlf_cDir="${gtlf_cDay}/${cCmpSvr_[$5]}/${gtlf_cLogSbtDir}"

        #ディレクトリの作成
        mkdir "$1/${gtlf_cDir}" > "${DEV_NULL}" 2>&1

        #ログファイルの件数分処理を実施する
        for gtlf_cLog in ${gtlf_cLogName[*]}
          do
            #ログファイルを一時領域に格納する

            mv "${cWrkDir_}/${DIR_LOG}/${gtlf_cLog}" "$1/${gtlf_cDir}/${gtlf_cLog}" \
               > "${DEV_NULL}" 2>&1

          done

#####2022/08/01 格納先変更 FTPでログ監理サーバに連携 #####
 
        #FTP実行時の標準入力ファイル（実行内容）の作成
        #ログ監理サーバへの接続
        echo "open ${PUT_ftpIP}"                     > "${cWrkDir_}/${FILE_FTP_ACT}"

        #ユーザＩＤ、パスワード入力
        echo "user ${PUT_ftpUser} ${PUT_ftpPass}"     >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #ログ監理サーバのNAS領域にディレクトリ作成
        #/renkei/temparea/収集対象日/サーバ(サーバ名)/ログ種別
        #再帰的に作成できないのでカレントディレクトリ移動→ディレクトリ作成→カレントディレクトリ移動を繰り返す
        #/renkei/temparea 作成
        echo "cd ${cColDat[$COL_RES]}"                >> "${cWrkDir_}/${FILE_FTP_ACT}"
        echo "mkdir ${DIR_TEMP_AREA}"                 >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #/renkei/temparea/YYYYMMDD 作成
        echo "cd ${DIR_TEMP_AREA}"                    >> "${cWrkDir_}/${FILE_FTP_ACT}"
        echo "mkdir ${gtlf_cDay}"                     >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #/renkei/temparea/YYYYMMDD/ホスト名 作成
        echo "cd ${gtlf_cDay}"                        >> "${cWrkDir_}/${FILE_FTP_ACT}"
        echo "mkdir ${cCmpSvr_[$5]}"                  >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #/renkei/temparea/YYYYMMDD/ホスト名/ログ種別 作成
        echo "cd ${cCmpSvr_[$5]}"                     >> "${cWrkDir_}/${FILE_FTP_ACT}"
        echo "mkdir ${gtlf_cLogSbtDir}"               >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #転送モードをバイナリモードに変更
        echo "binary"                                 >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #passiveモードに変更
        #echo "passive"                                >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #ログファイルの件数分処理を実施する
        for gtlf_cLog in ${gtlf_cLogName[*]}
          do
            #ログファイルをログ監理サーバのNAS領域に送信
#            echo "put "${cWrkDir_}/${DIR_LOG}/${gtlf_cLog}" "$1/${gtlf_cDir}/${gtlf_cLog}""   >> "${cWrkDir_}/${FILE_FTP_ACT}"
            echo "put "$1/${gtlf_cDir}/${gtlf_cLog}" "$1/${gtlf_cDir}/${gtlf_cLog}""   >> "${cWrkDir_}/${FILE_FTP_ACT}"
          done

        #接続を閉じる
        echo "close" >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #FTP終了
        echo "bye"   >> "${cWrkDir_}/${FILE_FTP_ACT}"

        #FTP実行
        ftp < "${cWrkDir_}/${FILE_FTP_ACT}" > "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" 2>&1
        cp ${cWrkDir_}/${FILE_FTP_ACT} /tmp/ftpput.txt
        cp ${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES} /tmp/ftpput_res.txt

        #FTP実行結果確認処理
        chkFtpResult "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}"

        #処理結果確認
        if [ "${NORMAL_FLG}" != "$?" ]
         then
          #FTP-GETエラーフラグに異常を設定
          gtlf_iErrFlg=${ERROR_FLG}

          #FTP接続エラー時のトレースログを出力する
          outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" \
                      "${TRACE_011}"

          #FTPエラー時、再収集リストにFTPエラーを記載する
          #再収集情報を作業領域の再収集情報ファイルに出力する
          #固定文出力 ログ中継サーバ→ログ監理サーバ FTP-GETPUTエラー
          outReTargetData "$3" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                          "${gtlf_cDay}" \
                          "${cCmpSvrJp_[$5]}" "${ERROR_FLG}"

          #収集結果を収集エラーとして収集結果ファイルに出力する
          outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                           "${gtlf_cDay}" "" "" "${COL_RES_ERR}"

         fi

      #FTP実行時の標準入力ファイルの削除
      if [ -f "${cWrkDir_}/${FILE_FTP_ACT}" ]
       then
         rm "${cWrkDir_}/${FILE_FTP_ACT}" > "${DEV_NULL}" 2>&1
       fi

      #FTP結果ファイルの削除
      if [ -f "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" ]
       then
        rm "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" > "${DEV_NULL}" 2>&1
       fi

      #収集結果をセキュリティログ有として収集結果ファイルに出力する
      outColResultData "$2" "${cCmpSvr_[$5]}" "${cCmpLogSbt_[$5]}" \
                       "${gtlf_cDay}" "/${gtlf_cDir}" \
                       "${gtlf_cLogName[*]}" "${COL_RES_GET}"


      #ログサイズを定義
      duResult=`du -bs $1/${gtlf_cDir}/`
#      duResult=`du -bs ${cWrkDir_}/${DIR_LOG}/${gtlf_cLog}`

      fileSize=$(( ${fileSize} + `echo ${duResult} | cut -d " " -f 1` ))
      filelist=`echo ${filelist} ${gtlf_cLogName[*]}`

      done

    #ログサイズをトレースログに出力　出力後リセット
    outTraceLog "${TRACE_INFOM}" "${TRACE_NORMAL_FLG}" "FTP終了,start = `date -d @${ftpStartTime} '+%Y/%m/%d %H:%M:%S'`,end = `date -d @${ftpEndTime} '+%Y/%m/%d %H:%M:%S'`,timediff = `expr ${ftpEndTime} - ${ftpStartTime}`,filelist = ${filelist},fileSize = ${fileSize}"

    filelist=""
    fileSize=0

    #/renkei/temparea内の収集したログファイルを削除
    if [ -d /renkei/temparea ]
     then

      #tempareaディレクトリ毎削除
      rm -r /renkei/temparea > "${DEV_NULL}" 2>&1

     fi

    #エラーフラグ（収集エラー）の確認
    if [ "${NORMAL_FLG}" != "${gtlf_iFlg}" ]
      #正常終了以外（収集エラー発生）の場合
      then
        #異常終了（収集エラー）
        return ${ERROR_FLG}
    fi

    #正常終了
    return ${NORMAL_FLG}

}

######################################<->#######################################
#  Name              : getLogSbtDir
#  Description       : ログ種別ディレクトリ取得処理
#  Inputs            : $1         :ログ種別（'N','A','O','E'）
#  Outputs           : ログ種別ディレクトリ
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
getLogSbtDir ()
{

echo_proc " -- ログ種別ディレクトリ取得処理 -- "

    case "$1" in
      #認証ログログ種別の場合
      ${LOG_SBT_N})
        echo "${LOG_SBT_N_DIR}"
        ;;
      #アクセスログの場合
      ${LOG_SBT_A})
        echo "${LOG_SBT_A_DIR}"
        ;;
      #オペレーションログの場合
      ${LOG_SBT_O})
        echo "${LOG_SBT_O_DIR}"
        ;;
      #その他ログの場合
      ${LOG_SBT_E})
        echo "${LOG_SBT_E_DIR}"
        ;;
      #2004.08.05 追加
      #アカウントログの場合
      ${LOG_SBT_C})
        echo "${LOG_SBT_C_DIR}"
        ;;
      #2004.08.05 追加
      #トレースログの場合
      ${LOG_SBT_T})
        echo "${LOG_SBT_T_DIR}"
        ;;
      #ログ種別が該当しない場合
      *)
        #収集構成定義情報取得時にチェック済みのためありえないが
        #該当してしまった場合にはその他ログのディレクトリ名を出力する。
        echo "${LOG_SBT_E_DIR}"
        ;;
    esac

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : cnvLogFileName
#  Description       : ログファイル名変換処理
#  Inputs            : $1            :ログファイル名コンベンション
#                    : $2            :収集対象日
#  Outputs           : ログファイル名
#  Return            : NORMAL_FLG    :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
cnvLogFileName ()
{

echo_proc " -- ログファイル名変換処理 -- "

    clfn_cLogFileName=""                    #ログファイル名

    #ログファイル名コンベンション("xxx-YYYYMMDD"形式)の"-YYYYMMDD"部分
    #を収集対象日で置換える
    clfn_cLogFileName=`echo "$1" | sed -e "s/-YYYYMMDD/-$2/"`

    #ログファイル名を出力
    echo "${clfn_cLogFileName}"

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : chkFtpResult
#  Description       : FTP実行結果確認処理
#  Inputs            : $1         :FTP-GETの結果ファイル
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#                    : ERROR_FLG  :異常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
chkFtpResult ()
{

echo_proc " -- FTP実行結果確認処理 -- "

    cfr_iCnt=0                              #カウンタ

    #接続エラー確認
    grep "${FTP_CONNECT_ERROR}" "$1" > "${DEV_NULL}" 2>&1
    if [ "${NORMAL_FLG}" = "$?" ]
      then
        #異常終了(FTP接続エラー)
        return ${ERROR_FLG}
    fi

    #認証エラー確認１
    grep "${FTP_CERTIFY_ERROR1}" "$1" > "${DEV_NULL}" 2>&1
    if [ "${NORMAL_FLG}" = "$?" ]
      then
        #異常終了(FTP認証エラー)
        return ${ERROR_FLG}
    fi

    #認証エラー確認２
    grep "${FTP_CERTIFY_ERROR2}" "$1" > "${DEV_NULL}" 2>&1
    if [ "${NORMAL_FLG}" = "$?" ]
      then
        #異常終了(FTP認証エラー)
        return ${ERROR_FLG}
    fi

    #正常終了
    return ${NORMAL_FLG}

}


######################################<->#######################################
#  Name              : chkReYMD
#  Description       : リトライ期間チェック処理
#  Inputs            : $1              :収集対象日
#                    : $2              :リトライ期間
#                    : $3              :収集対象日日数
#  Outputs           : なし
#  Return            : CHECK_RT_NORMAL :リトライ期間内
#                    : CHECK_RT_EQUAL  :リトライ期限
#                    : CHECK_RT_ERROR  :リトライ期間外
#  Procedures Called : subYMD          :日付減算処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
chkReYMD ()
{

echo_proc " -- リトライ期間チェック処理 -- "

    cry_cReYMD1=0                           #リトライ期限日１
    cry_cReYMD2=0                           #リトライ期限日２
    cry_iCalc=0                             #計算領域

    #システム日付?リトライ期限日
    cry_cReYMD1=`subYMD "${CNS_YMD}" "$2"`

    #収集対象日日数チェック
    if [ "$3" -le "${CHECK_1}" ]
      #収集対象日日数が１以下の場合（前日分が収集対象の場合）
      then
        #収集対象日１を収集対象日２に格納（リトライ期限日補正無し）
        cry_cReYMD2=${cry_cReYMD1}
      #収集対象日日数が２以上の場合（前日分以前も収集対象の場合）
      else
        #収集対象日日数?１日
        cry_iCalc=$(($3 - 1))
        #リトライ期限日?収集対象日日数
        cry_cReYMD2=`subYMD "${cry_cReYMD1}" "${cry_iCalc}"`
    fi

    #リトライ期限日２>=収集対象日かつ、リトライ期限日１<=収集対象日
    if [ "$1" -ge "${cry_cReYMD2}" -a "$1" -le "${cry_cReYMD1}" ]
      then
        #リトライ期限
        return ${CHECK_RT_EQUAL}
    fi

    #収集対象日がリトライ期限日２より前かつ、収集対象日が０日の場合
    #再収集処理のため、リトライ期限のものとする
    if [ "$1" -lt "${cry_cReYMD2}" -a "${CHECK_0}" -eq "$3" ]
      then
        #リトライ期限
        return ${CHECK_RT_EQUAL}
    fi

    #収集対象日がリトライ期限日２より前の場合
    if [ "$1" -lt "${cry_cReYMD2}" ]
      then
        #リトライ期間外
        return ${CHECK_RT_ERROR}
    fi

    #リトライ期間内
    return ${CHECK_RT_NORMAL}

}


######################################<->#######################################
#  Name              : outColResultData
#  Description       : 収集結果ファイル出力処理
#  Inputs            : $1         :収集結果ファイル
#                    : $2         :サーバ
#                    : $3         :ログファイル種類
#                    : $4         :ログファイル作成日
#                    : $5         :一時領域格納先
#                    : $6         :ログファイル名（配列形式）
#                    : $7         :収集結果
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################
outColResultData ()
{

echo_proc " -- 収集結果ファイル出力処理 -- "

    ocrd_cYMD=`date +"%Y%m%d"`              #日付
    ocrd_cHMS=`date +"%H%M%S"`              #時刻
    ocrd_cOutLog=""                         #ログファイル名編集領域
    ocrd_cLog=""                            #ログファイル名
    set -A ocrd_cLogNam                     #ログファイル名格納領域

    #ログファイル名の取得
    set -A ocrd_cLogNam $5

    #ログファイル名を出力形式に編集する
    #  ※ログファイル名を空白区切りで格納する
    for ocrd_cLog in ${ocrd_cLogNam[*]}
      do
        #ログファイル名編集領域への格納
        #ログファイル名＋空白を格納する
        ocrd_cOutLog="${ocrd_cOutLog}${ocrd_cLog} "
      done

    #ログファイル名編集領域の前後空白の削除
    ccrd_cOutLog=`echo ${ocrd_cOutLog}`

    #収集結果ファイルの出力
    #  出力内容
    #    "サーバ名,ログファイル種類,ログファイル作成日,収集処理実施日,
    #     収集処理実施時刻,一時領域格納先,ログファイル名,収集結果"
    #    ※ログファイル名が複数存在する場合は空白区切りで出力する
    #  区切り文字
    #    KGI_PGM:","
    echo -e "$2${KGI_PGM}\c"              >> "$1"
    echo -e "$3${KGI_PGM}\c"              >> "$1"
    echo -e "$4${KGI_PGM}\c"              >> "$1"
    echo -e "${ocrd_cYMD}${KGI_PGM}\c"    >> "$1"
    echo -e "${ocrd_cHMS}${KGI_PGM}\c"    >> "$1"
    echo -e "${ccrd_cOutLog}${KGI_PGM}\c" >> "$1"
    echo -e "$6${KGI_PGM}\c"              >> "$1"
    echo "$7"                          >> "$1"

    #正常終了
    return ${NORMAL_FLG}

}

# 収集処理-End

######################################<->#######################################
#  Name              : yicagnBackUp
#  Description       : 再収集リストバックアップ作成処理
#  Inputs            : なし
#  Outputs           : なし
#  Return            : NORMAL_FLG :正常終了
#  Procedures Called : なし
#  Date              : 2022.8.1
#  Update            :
#  概要             ：異常終了からのリラン対応時、再収集リスト(/renkei/yicagn.txt)のリカバリーが困難な為
#                    :過去５日分はバックアップを残す。（リラン時は再収集リストを上書きするだけで済む）
######################################<->#######################################
yicagnBackUp()
{
 backupDir="yicagn_backup"
 backupText="yicagn_${CNS_YMD}_${CNS_HMS}.txt"

 #バックアップ格納先ディレクトリが存在しなければ作成する
 if [ ! -d ${cColDat[$COL_RES]}/${backupDir} ]
  then
   mkdir ${cColDat[$COL_RES]}/${backupDir} > "${DEV_NULL}" 2>&1
  fi

 #再収集リストが存在すればバックアップを作成する
 if [ -f ${cColDat[$COL_RES]}/${FILE_YICAGN} ]
  then
   cp ${cColDat[$COL_RES]}/${FILE_YICAGN} ${cColDat[$COL_RES]}/${backupDir}/${backupText} > "${DEV_NULL}" 2>&1
  fi

 # 30日以上経過しているファイルを削除
 find ${cColDat[$COL_RES]}/${backupDir} -mtime +29 -exec rm {} \; 2> /dev/null

 #正常終了　（固定出力）
 return ${NORMAL_FLG}
}

# 再収集リストバックアップ作成処理-END




######################################<->#######################################
#  Name              : relayFTP
#  Description       : 収集処理結果ファイルFTP送信処理
#  Inputs            : なし
#  Outputs           : なし
#  Return            : NORMAL_FLG            :正常終了
#                    : ERROR_FLG             :異常終了
#  Date              : 2022.8.1
#  Update            :
#  概要             ：ログ中継サーバNAS廃止の為、ログ監理サーバへ処理結果ファイルをFTP送信する
######################################<->#######################################
relayFTP()
{
 #送信ファイル
 # /renkei/yicagn.txt (再収集情報ファイル)           :送信エラー時 正常終了扱い
 # /renkei/yictrres.txt (収集処理稼働結果ファイル）  :送信エラー時 正常終了扱い
 # /renkei/yicres.txt（収集結果ファイル）            :送信エラー時 異常終了

 #作業用ファイル 文字コード返還後ファイル
 EUC_yicagn=/tmp/yicagn.txt
 EUC_yictrres=/tmp/yictrres.txt
 EUC_yicres=/tmp/yicres.txt

#各作業用ファイルリセット
if [ -f "${EUC_yicagn}" ]
 then
  rm "${EUC_yicagn}"
 fi

if [ -f "${EUC_yictrres}" ]
 then
  rm "${EUC_yictrres}"
 fi

if [ -f "${EUC_yicres}" ]
 then
  rm "${EUC_yicres}"
 fi

#文字コードチェック
#変換処理を誤ると強制変換によりファイル破損する
cRet_yicagn=$(file /renkei/yicagn.txt)
cRet_yictrres=$(file /renkei/yictrres.txt)
cRet_yicres=$(file /renkei/yicres.txt)

#文字コードがEUCの場合 そのままコピー
#EUC以外ならEUCに変換する
if [[ "${cRet_yicagn}" = *ISO-8859* ]]
 then

  cp ${cColDat[$COL_RES]}/${FILE_YICAGN} ${EUC_yicagn}

 else

  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICAGN} -o ${EUC_yicagn}

 fi

if [[ "${cRet_yictrres}" = *ISO-8859* ]]
 then

  cp ${cColDat[$COL_RES]}/${FILE_YICTRRES} ${EUC_yictrres}

 else

  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICTRRES} -o ${EUC_yictrres}

 fi

if [[ "${cRet_yicres}" = *ISO-8859* ]]
 then

  cp ${cColDat[$COL_RES]}/${FILE_YICRES} ${EUC_yicres}

 else

  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICRES} -o ${EUC_yicres}

 fi


#文字コードがUTF-8の場合 EUCに変換
#if [[ "${cRet_yicagn}" = *utf-8* ]]
# then
#  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICAGN} -o ${EUC_yicagn}
# fi

#if [[ "${cRet_yictrres} = *utf-8* ]]
# then
#  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICTRRES} -o ${EUC_yictrres}
# fi

#if [[ ${cRet_yictres} = *utf-8* ]]
# then
#  iconv -f utf-8 -t EUC-JP ${cColDat[$COL_RES]}/${FILE_YICRES} -o ${EUC_yicres}
# fi

 #収集結果ファイル送信処理
 #FTP実行時の標準入力ファイル（実行内容）の作成
 #ログ監理サーバへの接続
 echo "open ${PUT_ftpIP}"                              > "${cWrkDir_}/${FILE_FTP_ACT}"

 #ユーザＩＤ、パスワード入力
 echo "user ${PUT_ftpUser} ${PUT_ftpPass}"            >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #転送モードをバイナリモードに変更
 echo "binary"                                        >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #passiveモードに変更
 #echo "passive"                                       >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #収集処理結果ファイルFTP送信
 echo "put ${EUC_yicres} ${cColDat[$COL_RES]}/${FILE_YICRES}"     >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #接続を閉じる
 echo "close" >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #FTP終了
 echo "bye"   >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #FTP実行
 ftp < "${cWrkDir_}/${FILE_FTP_ACT}" > "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" 2>&1
 cp ${cWrkDir_}/${FILE_FTP_ACT} /tmp/ftpput.txt
 cp ${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES} /tmp/ftpput_res.txt


 #エラーチェックの前にFTP実行時の標準入力ファイルの削除
 if [ -f "${cWrkDir_}/${FILE_FTP_ACT}" ]
  then
   rm "${cWrkDir_}/${FILE_FTP_ACT}" > "${DEV_NULL}" 2>&1
  fi

 #FTP結果ファイルの削除
  if [ -f "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" ]
   then
    rm "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" > "${DEV_NULL}" 2>&1
   fi

 #FTP実行結果確認処理
 chkFtpResult "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}"

 #処理結果確認
 if [ "${NORMAL_FLG}" != "$?" ]
  then
   #FTP接続エラー時のトレースログを出力する
    outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" \
                "${TRACE_012}"

    echo_proc " 【異常終了】 /renkei/yicres.txt 収集結果ファイルFTP送信エラー "

    #異常終了 他２つの送信処理は行わずに終了
    exit ${ERROR_FLG}

  fi




 #再収集情報ファイル、収集処理稼働結果ファイル送信処理
 #FTP実行時の標準入力ファイル（実行内容）の作成
 #ログ監理サーバへの接続
 echo "open ${PUT_ftpIP}"                              > "${cWrkDir_}/${FILE_FTP_ACT}"

 #ユーザＩＤ、パスワード入力
 echo "user ${PUT_ftpUser} ${PUT_ftpPass}"            >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #転送モードをバイナリモードに変更
 echo "binary"                                        >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #passiveモードに変更
 #echo "passive"                                       >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #収取処理稼働結果ファイル
 echo "put ${EUC_yictrres} ${cColDat[$COL_RES]}/${FILE_YICTRRES}" >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #再収集情報ファイルはない場合もあるので、ファイルが存在する場合のみ送信
 if [ -f /renkei/yicagn.txt ]
  then
    echo "put ${EUC_yicagn} ${cColDat[$COL_RES]}/${FILE_YICAGN}"  >> "${cWrkDir_}/${FILE_FTP_ACT}"
  fi

 #接続を閉じる
 echo "close" >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #FTP終了
 echo "bye"   >> "${cWrkDir_}/${FILE_FTP_ACT}"

 #FTP実行
 ftp < "${cWrkDir_}/${FILE_FTP_ACT}" > "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" 2>&1
 cp ${cWrkDir_}/${FILE_FTP_ACT} /tmp/ftpput.txt
 cp ${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES} /tmp/ftpput_res.txt

 #FTP実行結果確認処理
 chkFtpResult "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}"

 #処理結果確認 エラーでも正常終了
 if [ "${NORMAL_FLG}" != "$?" ]
  then
   #FTP接続エラー時のトレースログを出力する
   outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" \
               "${TRACE_013}"

   echo_proc "再収集情報ファイル or 収集処理稼働結果ファイル FTP送信エラー 【正常終了扱い】"

  fi

 #FTP実行時の標準入力ファイルの削除
 if [ -f "${cWrkDir_}/${FILE_FTP_ACT}" ]
  then
   rm "${cWrkDir_}/${FILE_FTP_ACT}" > "${DEV_NULL}" 2>&1
  fi

 #FTP結果ファイルの削除
 if [ -f "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" ]
  then
   rm "${cWrkDir_}/${DIR_LOG}/${FILE_FTP_RES}" > "${DEV_NULL}" 2>&1
  fi

#各作業用ファイル削除
if [ -f "${EUC_yicagn}" ]
 then
  rm "${EUC_yicagn}"
 fi

if [ -f "${EUC_yictrres}" ]
 then
  rm "${EUC_yictrres}"
 fi

if [ -f "${EUC_yicres}" ]
 then
  rm "${EUC_yicres}"
 fi

 #正常終了
 return ${NORMAL_FLG}
}

# 収集処理結果ファイルFTP送信処理-END





######################################<->#######################################
#  Name              : yilmlogc
#  Description       : セキュリティログ収集制御処理（メイン処理）
#  Inputs            : 引数$1                :収集種別
#  Outputs           : なし
#  Return            : NORMAL_FLG            :正常終了
#                    : ERROR_FLG             :異常終了
#                    : COL_ERROR_FLG         :収集エラー
#  Procedures Called : outTraceLog           :トレースログ出力処理
#                    : getCollectData        :収集定義情報取得処理
#                    : getParam              :引数取得処理
#                    : transactionCollectData:収集処理
#                    : outTransactionResult  :収集処理稼動結果ファイル出力処理
#                    : transactionVolumeCopy :ボリュームコピー処理
#  Date              : 2003.10.11
#  Update            :       
######################################<->#######################################

echo_proc "<-- セキュリティログ収集処理開始 `date +'%Y/%m/%d %H:%M:%S'` -->"

    iErrFlg=${NORMAL_FLG}                   #エラーフラグ（収集処理）
    iVolCopyFlg=${NORMAL_FLG}               #エラーフラグ（ボリュームコピー）
    iRetStatus=${NORMAL_FLG}                #処理結果
    iPrcStatus=${NORMAL_FLG}                #処理結果（関数）
    cColSbt=""                              #収集種別
    set -A cColDat                          #収集定義情報格納先（配列形式）

    #--------------------------------------------------------------------------#
    # トレースログの出力                                                       #
    #--------------------------------------------------------------------------#
    # セキュリティログ収集処理の処理開始時のトレースログを出力する
    outTraceLog "${TRACE_INFOM}" "${TRACE_NORMAL_FLG}" "${TRACE_001}"

    #--------------------------------------------------------------------------#
    # 収集定義情報取得処理                                                     #
    #--------------------------------------------------------------------------#
    # 収集定義ファイルより収集定義情報を取得する
    set -A cColDat `getCollectData "${DIR_CONF}/${FILE_YICDEF}"`

    #収集定義情報取得処理の処理結果判定
    iPrcStatus=$?

echo_proc "    収集定義情報取得処理-処理結果                :${iPrcStatus}"

    if [ "${NORMAL_FLG}" != "${iPrcStatus}" ]
      #処理結果が正常終了以外の場合
      then
        #----------------------------------------------------------------------#
        # トレースログの出力                                                   #
        #----------------------------------------------------------------------#
        # 収集定義情報取得エラーのトレースログを出力する
        outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_005}"

        #処理結果に異常を格納
        iRetStatus=${ERROR_FLG}
    fi

echo_proc "    収集構成定義ファイル格納先                   :${cColDat[$COL_DEF]}"
echo_proc "    収集処理結果格納先                           :${cColDat[$COL_RES]}"
echo_proc "    サーバ区分(0:監理,1:収集)                    :${cColDat[$COL_SVR]}"
echo_proc "    リトライ期間                                 :${cColDat[$COL_RET]}"

    #引数の取得
    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
      then
        #----------------------------------------------------------------------#
        # 引数取得処理                                                         #
        #----------------------------------------------------------------------#
        # 引数から収集種別を取得する
        cColSbt=`getParam "$@"`
        # 引数に収集日が指定されている場合は変数にセットする
        if [ ${#} = 2 ]; then
          if [ `echo ${2} | grep -E "^[0-9]{4}[0-1][0-9][0-3][0-9]$"` ]; then
            cColYMD=${2}
          else
            # 引数取得エラーのトレースログを出力する
            outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_006}"
            iRetStatus=${ERROR_FLG}
            exit ${iRetStatus}
          fi
        else
          cColYMD=""
        fi

        #引数取得処理の処理結果判定
        iPrcStatus=$?
        if [ "${NORMAL_FLG}" != "${iPrcStatus}" ]
          #処理結果が正常終了以外の場合
          then
            #------------------------------------------------------------------#
            # トレースログの出力                                               #
            #------------------------------------------------------------------#
            # 引数取得エラーのトレースログを出力する
            outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" \
                        "${TRACE_006}"

            #処理結果に異常終了を格納
            iRetStatus=${ERROR_FLG}

        fi

echo_proc "    引数取得処理-処理結果                        :${iPrcStatus}"
echo_proc "    収集種別                                     :${cColSbt}"

    fi

# 以下のボリュームコピーは共用ストレージ（NAS）利用に伴い廃止 ⇒ 廃止（コメント化） 
# 2010.08.31
# コメント化　Ｓｔａｒｔ
#    #収集処理結果格納先のmount
#    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
#      then
#
#        #サーバ区分が収集サーバの場合実施
#        if [ "${SVR_COL}" = "${cColDat[$COL_SVR]}" ]
#          then
#
#            #------------------------------------------------------------------#
#            # 収集処理結果格納先のmount                                        #
#            #------------------------------------------------------------------#
#            # 収集処理結果格納先のmountの実施
##            mount "${cColDat[$COL_RES]}" > "${DEV_NULL}" 2>&1
#echo_proc "収集処理結果格納先：mount"
#
#            #存在確認
#            if [ ! -d "${cColDat[$COL_RES]}" ]
#              then
#                #--------------------------------------------------------------#
#                # トレースログの出力                                           #
#                #--------------------------------------------------------------#
#                # 収集定義情報取得エラーのトレースログを出力する
#                # 収集定義情報に不正が有る可能性が高いため収集定義情報エラーとする
#                outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_005}"
#
#                #処理結果に異常を格納
#                iRetStatus=${ERROR_FLG}
#            fi
#        fi
#    fi
# コメント化 Ｅｎｄ

    #--------------------------------------------------------------------------#
    # 作業領域の作成                                                           #
    #--------------------------------------------------------------------------#
    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
      then

        #サーバ区分が監理サーバの場合
        if [ "${SVR_MGR}" = "${cColDat[$COL_SVR]}" ]
          then
            #作業領域１の存在チェック
            if [ -d "${DIR_SEC_LOG_1}" ]
              then
                #作業領域１を作業領域名とする
                cWrkDir_="${DIR_SEC_LOG_1}/${DIR_WORK}"
                # 作業領域を作成する
                mkdir "${cWrkDir_}" > "${DEV_NULL}" 2>&1
              else
                #処理結果に異常を格納
                iRetStatus=${ERROR_FLG}
            fi
        fi

        #サーバ区分が収集サーバの場合
        if [ "${SVR_COL}" = "${cColDat[$COL_SVR]}" ]
          then
            #作業領域２の存在チェック
            if [ -d "${DIR_SEC_LOG_2}" ]
              then
                #作業領域１を作業領域名とする
                cWrkDir_="${DIR_SEC_LOG_2}/${DIR_WORK}"
                # 作業領域を作成する
                mkdir "${cWrkDir_}" > "${DEV_NULL}" 2>&1
              else
                #処理結果に異常を格納
                iRetStatus=${ERROR_FLG}
            fi
        fi

        #サーバ区分が監理サーバでも、収集サーバでも、ない場合
        if [ "${SVR_MGR}" != "${cColDat[$COL_SVR]}" -a \
             "${SVR_COL}" != "${cColDat[$COL_SVR]}"     ]
          then
            #処理結果に異常を格納
            iRetStatus=${ERROR_FLG}
        fi
    fi

    #--------------------------------------------------------------------------#
    # 処理前 再収集リストバックアップ作成                                      #
    #--------------------------------------------------------------------------#
    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
      then
       yicagnBackUp
      fi

    #セキュリティログの収集
    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
      then
        #----------------------------------------------------------------------#
        # 収集処理                                                             #
        #----------------------------------------------------------------------#
        # 収集構成定義ファイルを読込み、収集種別に該当するセキュリティログを
        # FTP-GETで取得し、収集結果格納先に格納する
        # -- 引数2に日付(YMD)が指定された場合の判定＆サブルーチンコール ## DATE:2022/10/14
        if [ ${#} = 2 ]; then
        transactionCollectData "${cColSbt}" "${cColDat[$COL_DEF]}" \
                               "${cColDat[$COL_RES]}" "${cColDat[$COL_RET]}" "${cColYMD}"
        else
        transactionCollectData "${cColSbt}" "${cColDat[$COL_DEF]}" \
                               "${cColDat[$COL_RES]}" "${cColDat[$COL_RET]}"
        fi

        #収集処理の処理結果判定
        iPrcStatus=$?
        if [ "${COL_ERROR_FLG}" = "${iPrcStatus}" ]
          #処理結果が収集エラーの場合
          then
            #エラーフラグに収集エラーを格納
            iErrFlg=${COL_ERROR_FLG}
          else
            if [ "${NORMAL_FLG}" != "${iPrcStatus}" ]
              #処理結果が収集エラー以外かつ、正常終了以外の場合
              #現状では収集構成定義ファイルにエラーが発生した場合が該当する
              then
                #エラーフラグに異常終了を格納
                iErrFlg=${ERROR_FLG}
            fi
        fi

echo_proc "    収集処理-処理結果                            :${iPrcStatus}"

        #----------------------------------------------------------------------#
        # 収集処理稼動結果ファイル出力処理                                     #
        #----------------------------------------------------------------------#
        # 収集処理稼動結果ファイルを出力する
        #  処理結果：正常終了
        #            収集エラー
        #            異常終了
        #収集処理稼動結果ファイル出力処理
        outTransactionResult "${cColDat[$COL_RES]}" "${cColSbt}" "${CNS_YMD}" \
                             "${CNS_HMS}" "${iErrFlg}"

# 以下のボリュームコピーは共用ストレージ（NAS）利用に伴い廃止 ⇒ 廃止（コメント化）
# 2010.08.31
# コメント化　Ｓｔａｒｔ
#        #サーバ区分が収集サーバの場合は収集処理結果格納先をumountする
#        if [ "${SVR_COL}" = "${cColDat[$COL_SVR]}" ]
#          then
#            #------------------------------------------------------------------#
#            # 収集処理結果格納先のumount                                      #
#            #------------------------------------------------------------------#
#            # 収集処理結果格納先のumountの実施
#            umount "${cColDat[$COL_RES]}" > "${DEV_NULL}" 2>&1
#echo_proc "収集処理結果格納先：umount"
#        fi
# コメント化 Ｅｎｄ

    fi

    #--------------------------------------------------------------------------#
    # 収集処理結果ファイルFTP送信処理                                          #
    #--------------------------------------------------------------------------#
    if [ "${NORMAL_FLG}" = "${iRetStatus}" ]
      then

       relayFTP

      fi

    #FTP送信処理の処理結果判定
    iPrcStatus=$?

    if [ "${COL_ERROR_FLG}" = "${iPrcStatus}" ]
    #処理結果がFTP送信エラーの場合 （処理結果ファイルの送信エラーに限る）
    then

     #処理結果に異常を格納
     iRetStatus=${ERROR_FLG}

    fi

    #--------------------------------------------------------------------------#
    # トレースログの出力                                                       #
    #--------------------------------------------------------------------------#
    # セキュリティログ収集処理の処理終了時のトレースログを出力する
    if [ "${NORMAL_FLG}" = "${iRetStatus}" -a \
         "${NORMAL_FLG}" = "${iErrFlg}"        ]
      #処理結果、エラーフラグ（収集処理）が全て正常終了の場合
      then
        #トレースログ出力（正常終了）
        outTraceLog "${TRACE_INFOM}" "${TRACE_NORMAL_FLG}" "${TRACE_009}"
      #処理中にエラーが発生した場合
      else
        #トレースログ出力（異常終了）
        outTraceLog "${TRACE_FATAL}" "${TRACE_ERROR_FLG}" "${TRACE_010}"
    fi

    #--------------------------------------------------------------------------#
    # 作業領域の削除                                                           #
    #--------------------------------------------------------------------------#
    # 作業領域の削除（存在する場合のみ）
    if [ "${cWrkDir_}" != "" ]
      then
        if [ -d "${cWrkDir_}" ]
          then
            rm -r "${cWrkDir_}" > "${DEV_NULL}" 2>&1
        fi
    fi

    #--------------------------------------------------------------------------#
    # 処理結果の返却                                                           #
    #--------------------------------------------------------------------------#
    # 呼び出し元に処理結果を返却し、処理を終了する

    #処理結果の設定
    if [ "${SVR_COL}"    != "${cColDat[$COL_SVR]}" ]
      #サーバ区分が監理サーバの場合
      then
        if [ "${NORMAL_FLG}"  !=  "${iErrFlg}" ]
          #エラーフラグ（収集処理）が収集エラーまたは、異常終了の場合
          then
            #処理結果にエラーフラグの内容を設定
            iRetStatus=${iErrFlg}
        fi
    fi

echo_proc "    セキュリティログ収集処理-処理結果            :${iRetStatus}"
echo_proc "<-- セキュリティログ収集処理終了 `date +'%Y/%m/%d %H:%M:%S'` -->"

    #処理結果を返却
    #  ログ中継サーバ（サーバ区分が収集サーバの場合）
    #    ０      ：正常終了（収集エラーのケースも該当）
    #    上記以外：異常終了（収集定義ファイル内容の異常、引数の指定異常のケース）
    #    ※ログ中継サーバの収集処理の処理結果は収集処理稼動結果ファイルにて確認
    #      するものとする
    #
    #  ログ監理サーバ（サーバ区分が監理サーバの場合）
    #    ０      ：正常終了
    #    ２      ：収集エラー
    #    上記以外：異常終了（収集定義ファイル内容の異常、引数の指定異常のケース）
    #    ※ログ監理サーバはボリュームコピーは行わないため、ボリュームコピーエラー
    #      の処理結果は返却されない
    exit ${iRetStatus}

# セキュリティログ収集処理-End
