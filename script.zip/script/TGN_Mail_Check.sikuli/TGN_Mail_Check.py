# 初期設定
import sys
import time
import ConfigParser
import datetime

reload(sys)
reload(time)
reload(ConfigParser)

sys.setdefaultencoding("utf-8")
config = ConfigParser.ConfigParser()
config.read("C:\\SmartOP\sikuli\mail.txt")

log = open('C:\\SmartOP\sikuli\log.txt', 'a')
strs = "-----------------------------check start:" + str(datetime.datetime.today()) + "------------------------------\n" 
log.write(strs)

# checkスタート時間測定
chktime1 = time.time()
#### for文でconfigファイルからID,PASSの読出し ###
for i in range(8):
    i = i + 1
    userid = "user0%d" % i

    user = config.get(userid, 'user')
    pswd = config.get(userid, 'pass')
    
    # Outlook起動
    click(Pattern("1643935780543.png").similar(0.90))

    # マウスをOutlookアイコンから外す処理 2017/5/9
    mouseMove(Location(0,0))
    
#  2017/5/9　ログ出力移動
#    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Outlookを起動しました\n"
#    log.write(strs)
  
# プロファイル選択
#    wait(Pattern("1643935871259.png").similar(0.90),10) waitからリトライに変更       
    while not exists(Pattern("1643935871259.png").similar(0.90),20):
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Outlookの起動をリトライします\n"
        log.write(strs) 
        wait(5)
        click(Pattern("1643935780543.png").similar(0.90))
        mouseMove(Location(500,500))
# プロファイル名消去　2022/2/4追加　ここから
    type("a",Key.CTRL)
    type(Key.DELETE)
# プロファイル名消去　2022/2/4追加　ここまで
    paste(user)
    type(Key.ENTER)

    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Outlookの起動に成功しました\n"
    log.write(strs)
    
    #　パスワード入力
    paste(Pattern("1643936600244.png").similar(0.90), pswd)
    type(Key.ENTER)

    # Outlook 起動スタート時間測定
    oltime1 = time.time()

    # Outlook 画面表示確認
    wait(Pattern("1643936879245.png").similar(0.90),120)

    # Outlook 起動完了時間測定＆結果表示
    oltime2 = time.time()
    oltime3 = oltime2 - oltime1
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Outlookの起動にかかった時間:" + str(oltime3) + "s\n"
    log.write(strs)
    wait(2)
    
    # 2017/5/9 ウィンドウ最大化処理　追加
    type(" ",KEY_ALT)
    wait(1)
    type("x")


    # smartop_outlook メール送信
    mail = user + "@tepco.co.jp"
    click(Pattern("1643936945513.png").similar(0.90))
    wait(Pattern("1643937462233.png").similar(0.90),10)
    paste(mail)
    type(Key.TAB)
    type(Key.TAB)
    type(Key.TAB)
    paste(Pattern("1643937022574.png").similar(0.90),"smartop_outlook")
    type(Key.TAB)
    paste("smartop_outlook")
    click(Pattern("1643937080728.png").similar(0.90))
    wait(1)

    # smartop_outlook 受信確認
#    wait(Pattern("1643937371560.png").similar(0.90),20)
    if exists(Pattern("1643937371560.png").similar(0.90)):
        strs = str(datetime.datetime.today())  + "," + userid + "," + user + "," + u"[OK]SmartOP_Outlookメール受信確認\n"
        log.write(strs)
        click(Pattern("1643937371560.png").similar(0.90))
    else: 
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[NG]SmartOP_Outlookメール受信異常\n"
        log.write(strs)

    # smartop_outlook_delete メール送信
    if user == "x0015458":
        mail = user + "@tepco.co.jp"
        click(Pattern("1643936945513.png").similar(0.90))
        wait(Pattern("1643937462233.png").similar(0.90),10)
        paste(mail)
        type(Key.TAB)
        type(Key.TAB)
        type(Key.TAB)
        paste(Pattern("1643937022574.png").similar(0.90),"smartop_outlook_delete")
        type(Key.TAB)
        paste("smartop_outlook_delete")
        click(Pattern("1643937080728.png").similar(0.90))
        wait(1)

        # smartop_outlook_delete 受信確認
#        wait(Pattern("1643937603723.png").similar(0.90),10)
        if exists(Pattern("1643937603723.png").similar(0.90)):
            strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[OK]SmartOP_Outlook_deleteメール受信確認\n"
            log.write(strs)
            click(Pattern("1643937603723.png").similar(0.90))
        else: 
            strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[NG]SmartOP_Outlook_deleteメール受信異常\n"
            log.write(strs)

    # アドレス帳の確認
    wait(Pattern("1643937657798.png").exact(),10)
    click(Pattern("1643937657798.png").exact())
    wait(Pattern("1643937709060.png").similar(0.90),100)

    if exists(Pattern("1643937763896.png").similar(0.90),100):
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + "[OK]アドレス帳確認\n"
        log.write(strs)
    else: 
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[NG]アドレス帳異常\n"
        log.write(strs)
    wait(Pattern("1643937709060.png").similar(0.90),100)
    click(Pattern("1643937875550.png").exact())

    # 階層型アドレス帳の確認
    wait(Pattern("1643937908064.png").similar(0.90),10)
    click(Pattern("1643937908064.png").similar(0.90))
    wait(Pattern("1643937946234.png").similar(0.90),100)
    wait(1)
    if exists(Pattern("1643937974715.png").similar(0.90),100):
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[OK]階層型アドレス帳確認\n"
        log.write(strs)
    else: 
        strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[NG]階層型アドレス帳異常\n"
        log.write(strs)
    click(Pattern("1643937996112.png").similar(0.90))

#    ask =popAsk(u"操作を続けますか？",u"確認")
#    if ask == "NG":
#        exit(0)
    # Outlook 終了
    wait(1)
    click(Pattern("1643938051608.png").similar(0.90))
    wait(Pattern("1643938085817.png").similar(0.90))
    click(Pattern("1643938085817.png").similar(0.90))
    wait(3)
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Outlookを閉じました\n"
    log.write(strs)
    
# checkスタート時間測定
chktime2 = time.time()
chktime3 = chktime2 - chktime1
strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Check time:" + str(chktime3) + "s\n"
log.write(strs)
log.close()