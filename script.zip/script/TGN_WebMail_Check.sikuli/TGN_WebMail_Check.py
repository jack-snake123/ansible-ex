# 初期設定
import sys
import time
import ConfigParser
import datetime

reload(sys)
reload(time)
reload(ConfigParser)

sys.setdefaultencoding("utf-8")
config = ConfigParser.ConfigParser()
config.read("C:\\SmartOP\sikuli\mail.txt")

log = open('C:\\SmartOP\sikuli\owa.txt', 'a')
strs = "-----------------------------check start:" + str(datetime.datetime.today()) + "------------------------------\n" 
log.write(strs)

# checkスタート時間測定
chktime1 = time.time()
#### for文でconfigファイルからID,PASSの読出し ###
for i in range(8):
#for i in range(1):
    i = i + 1
    userid = "user0%d" % i

    user = config.get(userid, 'user')
    pswd = config.get(userid, 'pass')
    
    # Outlook起動
    click(Pattern("1643938459807.png").similar(0.90))
    # マウスをIEアイコンから外す処理
    mouseMove(Location(500,500))
    wait(Pattern("1646794292362.png").similar(0.90),30)
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]IEの起動に成功しました\n"
    log.write(strs)
    
    #ウィンドウ最大化処理
    type(" ",KEY_ALT)
    wait(1)
    type("x")
    for x in range(3):
        if exists(Pattern("1646793882573.png").similar(0.95),3):
            break
        else:
            type(" ",KEY_ALT)
            wait(1)
            type("x")

    #ＴＥＰＣＯ 共通ログイン ログイン処理
    paste(Pattern("1643938512877.png").similar(0.90), user)
    wait(1)
    paste(Pattern("1643938522475.png").similar(0.90), pswd)
    wait(1)
    click(Pattern("1643938582847.png").similar(0.90))
    wait(Pattern("1643938643932.png").similar(0.90),30)

    #メールシステム(Web版)にログイン
    click(Pattern("1643938643932.png").similar(0.90))
    wait(Pattern("1643938686515.png").similar(0.90),30)
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]TEPCO共通ログインに成功しました\n"
    log.write(strs)

    #メッセージの作成処理
    mail = user + "@tepco.co.jp"
    mouseMove(Location(0,0))
    click(Pattern("1643938708338.png").similar(0.90))
    wait(Pattern("1643938734344.png").similar(0.90),30)
    paste(mail)
#    type(Key.TAB*5) 品質向上のためTAB実行後のwait追加　2022/02/04　ここから
    wait(1)
    type(Key.TAB)
    wait(1)
    type(Key.TAB)
    wait(1)
    type(Key.TAB)
    wait(1)
    type(Key.TAB)
    wait(1)
    type(Key.TAB)
    wait(1)
#    type(Key.TAB*5) 品質向上のためTAB実行後のwait追加　2022/02/04　ここまで
    paste("smartop_owa")
    wait(1)
#    type(Key.TAB*2) 品質向上のためTAB実行後のwait追加　2022/02/04　ここから
    type(Key.TAB)
    wait(1)
    type(Key.TAB)
    wait(1)
#    type(Key.TAB*2) 品質向上のためTAB実行後のwait追加　2022/02/04　ここまで
    paste("smartop_owa")
    wait(1)
    click(Pattern("1643938759045.png").similar(0.90))
    wait(Pattern("1643938708338.png").similar(0.90),30)
    
    #smartop_owa受信確認
    # -- 2022/03/15 メール到着確認が出来ない場合は再度メール受信を実施(計5秒*12回ループ)
    wait(3)
    click(Pattern("1643938789711-1.png").similar(0.90))
    mouseMove(Location(0,0))
    mailok = 0
    for x in range(12):
        if exists(Pattern("1646794470309-1.png").similar(0.90),5):
            strs = str(datetime.datetime.today())  + "," + userid + "," + user + "," + u"[OK]SmartOP_owaメール受信確認\n"
            log.write(strs)
            click(Pattern("1646794470309-1.png").similar(0.90))
            for z in range(3):
                if exists(Pattern("1643939033342-1.png").similar(0.90),10):
                    click(Pattern("1643938789711-1.png").similar(0.90))
                    mouseMove(Location(0,0))
                    mailok = 1
                    break
                elif exists(Pattern("1646794470309-1.png").similar(0.90),3):
                    click(Pattern("1646794470309-1.png").similar(0.90))
        elif x == 11: 
            strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[NG]SmartOP_owメール受信異常\n"
            log.write(strs)
            print('error')
        else:
            click(Pattern("1643938789711-1.png").similar(0.90))
            mouseMove(Location(0,0))

        # -- mailok = 1の場合はループを抜ける
        if mailok == 1:
            break

    #Outlook Web App 終了処理
    wait(Pattern("1643939078925.png").similar(0.90).targetOffset(111,-4),30)
    click(Pattern("1643939078925.png").similar(0.90).targetOffset(112,0))
    wait(Pattern("1643938643932.png").similar(0.90),30)
    
    # ＴＥＰＣＯ 共通ログインログアウト処理
    click(Pattern("1643939148484.png").similar(0.90))
    wait(Pattern("1643939167320.png").similar(0.90),30)
    click(Pattern("1643939184365.png").exact())
    wait(Pattern("1646794292362.png").similar(0.90),30)
    wait(5)
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]TEPCO共通ログアウトに成功しました\n"
    log.write(strs)

    #IE終了処理
    type(" ",KEY_ALT)
    type("c")
    strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]IEの終了に成功しました\n"
    log.write(strs)
    
    
# checkスタート時間測定
chktime2 = time.time()
chktime3 = chktime2 - chktime1
strs = str(datetime.datetime.today()) + "," + userid + "," + user + "," + u"[Info]Check time:" + str(chktime3) + "s\n"
log.write(strs)
log.close()