# -*- coding: utf-8 -*-
import re, traceback
from argparse import ArgumentParser

# 繰り返し文字列の作成
def repeat_string(s, num):
    return s * num

# 引数チェック
def args_parser():
    usage = '{} start_int end_int'.format(__file__)

    argparser = ArgumentParser(usage=usage)
    argparser.add_argument('start_int', type=int, help='開始数値')
    argparser.add_argument('end_int', type=int, help='終了数値')

    return argparser.parse_args()

# 全角から半角へ変換
def to_half_width(str_val):
    # 半角変換
    half_val = re.sub(r'[\uff08-\uff5e]', lambda x: chr(ord(x.group(0)) - 0xFEE0), str_val)
    # 文字コードシフトで対応できない文字の変換
    return (half_val
            .replace('＋', '+')
            .replace('ー', '-')
            .replace('?', '-')
            .replace('×', '*')
            .replace('÷', '/')
            .replace('　', ' '))

# 正規表現パーツ文字の生成
def make_brackets(str1, str2):
    if str1 == str2:
        return str1
    else:
        return '['+str(str1)+'-'+str(str2)+']'

def make_braces(str1, str2=None):
    if str2 is None or str1 == str2:
        if int(str1) == 1:
            return ''
        else:
            return '{'+str(str1)+'}'
    else:
        return '{'+str(str1)+','+str(str2)+'}'

def add_minus(s):
    return '-('+s+')'

def add_decimal(s):
    return '('+s+')(\.[0-9]+)?'

def add_clip(s):
    return '(?<=[^0-9\.])('+s+')(?=[^0-9\.])'

# 数値範囲の正規表現を生成
def number_range_regexp(start, end, with_decimal=False):
    if start == '' and end == '':
        return ''
    elif start == '' or end == '':
        if start == '':
            start = end
        if end == '':
            end = start

    start_value = int(start)
    end_value = int(end)

    if start_value == end_value:
        return str(start_value)

    is_minus = False

    if start_value < 0 and end_value < 0:
        is_minus = True
        start_value = -start_value
        end_value = -end_value

    if start_value > end_value:
        start_value, end_value = end_value, start_value

    if start_value < 0 and end_value >= 0:
        if with_decimal:
            if start_value == -1:
                ex = start_value+'|'+add_decimal("-0")+'|'
            else:
                ex = start_value+'|'+add_decimal(add_minus(make_number_range_regexp(0, -start_value - 1)))+'|'
            if end_value == 0:
                ex += '0'
            elif end_value == 1:
                ex += add_decimal("0")+'|'+end_value
            else:
                ex += add_decimal(make_number_range_regexp(0, end_value - 1))+'|'+end_value
        else:
            if start_value == -1:
                ex = start_value+'|'
            else:
                ex = add_minus(make_number_range_regexp(1, -start_value))+'|'
            if end_value == 0:
                ex += '0'
            else:
                ex += make_number_range_regexp(0, end_value)
    else:
        if with_decimal:
            ex = add_decimal(make_number_range_regexp(0, end_value - 1))+'|'+end_value
        else:
            ex = make_number_range_regexp(start_value, end_value)
        if is_minus:
            ex = add_minus(ex)
    return ex

def make_number_range_regexp(start_value, end_value):
    start_str = str(start_value)
    end_str = str(end_value)
    start_digit = len(start_str)
    end_digit = len(end_str)
    agree_digit = 0

    if start_digit == end_digit:
        for i in range(start_digit, 0, -1):
            if start_str[:i] == end_str[:i]:
                agree_digit = i
                break
        if start_digit - agree_digit == 1:
            ex = ''
            if start_digit > 1:
                ex = start_str[:start_digit - 1]
            ex += make_brackets(start_str[start_digit - 1], end_str[start_digit - 1])
            return ex

    lower_thre = None
    upper_thre = None

    exL = ""
    if re.match(r'^[1-9]0+$', start_str):
        lower_thre = start_str
    elif re.match(r'^[1-9]9+$', start_str):
        exL = start_str+'|'
        lower_thre = str(int(start_str[0]) + 1) + '0' * (start_digit - 1)
    else:
        if start_digit == 1:
            exL = make_brackets(start_str, "9")+'|'
            lower_thre = '10'
        else:
            for i in range(2, start_digit - agree_digit):
                if int(start_str[start_digit - i]) != 9:
                    if int(start_str[:start_digit - i] + '9' * i) <= end_value:
                        exL += start_str[:start_digit - i]+make_brackets(str(int(start_str[start_digit - i]) + 1), "9")
                        if i - 1 > 0:
                            exL += '[0-9]'+make_braces(i - 1)
                        exL += '|'
            exL = start_str[:start_digit - 1]+make_brackets(start_str[start_digit - 1], "9")+'|'+exL
            lower_thre = str(int(start_str[:agree_digit + 1]) + 1) + '0' * (start_digit - agree_digit - 1)

    exU = ""
    if re.match(r'^[1-9]9+$', end_str):
        upper_thre = end_str
    elif re.match(r'^[1-9]0+$', end_str):
        exU = end_str
        upper_thre = str(int(end_str[:2]) - 1) + '9' * (end_digit - 2)
    else:
        for i in range(2, end_digit - agree_digit):
            if int(end_str[end_digit - i]) != 0:
                exU = end_str[:end_digit - i]+make_brackets("0", str(int(end_str[end_digit - i]) - 1))+'[0-9]'+make_braces(i - 1)+'|'+exU
        exU = exU+end_str[:end_digit - 1]+make_brackets("0", end_str[end_digit - 1])+'|'
        upper_thre = str(int(str(int(end_str[:agree_digit + 1]) - 1) + '9' * (end_digit - agree_digit - 1)))

    exM = ""
    if int(lower_thre) < int(upper_thre):
        lower_digit = len(lower_thre)
        upper_digit = len(upper_thre)

        if lower_digit == upper_digit:
            exM = lower_thre[:agree_digit]+make_brackets(lower_thre[agree_digit], upper_thre[agree_digit])+'[0-9]'+make_braces(lower_digit - agree_digit - 1)+'|'
        else:
            if lower_thre[0] == '1':
                if upper_thre[0] == '9':
                    exM = make_brackets("1", "9")+make_brackets("0", "9")+make_braces(lower_digit - 1, upper_digit - 1)+'|'
                else:
                    exM = make_brackets("1", "9")+make_brackets("0", "9")+make_braces(lower_digit - 1, upper_digit - 2)+'|'
                    exM += make_brackets("1", upper_thre[0])+make_brackets("0", "9")+make_braces(upper_digit - 1)+'|'
            else:
                if upper_thre[0] == '9':
                    exM = make_brackets(lower_thre[0], "9")+make_brackets("0", "9")+make_braces(lower_digit - 1)+'|'
                    exM += make_brackets("1", "9")+make_brackets("0", "9")+make_braces(lower_digit, upper_digit - 1)+'|'
                else:
                    exM = make_brackets(lower_thre[0], "9")+make_brackets("0", "9")+make_braces(lower_digit - 1)+'|'
                    if upper_digit - lower_digit > 1:
                        exM += make_brackets("1", "9")+make_brackets("0", "9")+make_braces(lower_digit, upper_digit - 2)+'|'
                    exM += make_brackets("1", upper_thre[0])+make_brackets("0", "9")+make_braces(upper_digit - 1)+'|'

    ex = exL + exM + exU
    if ex.endswith('|'):
        ex = ex[:-1]
    return ex

try:
    args = args_parser()
    ans = number_range_regexp(args.start_int, args.end_int)
    print(ans)
except Exception as e:
    print(traceback.format_exc())
    rc = 99
else:
    rc = 0
finally:
    exit(rc)