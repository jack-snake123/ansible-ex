$namelist = import-csv -path idlist_d.txt -Encoding Default

foreach ($idl in $namelist) {
  $id = $idl.id
  $name = $idl.name
  New-LocalUser -Name $id -Password (ConvertTo-SecureString $id -AsPlainText -Force) -FullName $name
    Add-LocalGroupMember -Group "Users" -Member $id
    Add-LocalGroupMember -Group "Remote Desktop Users" -Member $id
}
