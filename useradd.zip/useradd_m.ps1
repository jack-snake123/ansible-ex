$namelist = import-csv -path idlist_m.txt -Encoding Default

foreach ($idl in $namelist) {
  $id = $idl.id
  $name = $idl.name
  New-LocalUser -Name $id -Password (ConvertTo-SecureString $id -AsPlainText -Force) -FullName $name
  Add-LocalGroupMember -Group "Administrators" -Member $id
}