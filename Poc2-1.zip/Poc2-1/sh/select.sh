#!/bin/bash

case "$1" in
        RHEL6.x86)
        echo "acquirelin26x86.tar"
        ;;
        RHEL6.x64)
        echo "acquirelin26rhel5x64.tar"
        ;;
        RHEL6.z)
        echo "acquirezlin26rhel65.tar"
        ;;
        RHEL7.x64)
        echo "acquirelin26rhel5x64.tar"
        ;;
        RHEL7.z)
        echo "acquirezlin26rhel7.tar"
        ;;
esac
