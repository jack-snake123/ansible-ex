#!/bin/bash
# -- Jenkinsのcrumb取得
jenkins_user="jenkins:11148b81eebb0e983c2665c1fc62a09909"
crumb=$(curl -k -s -u ${jenkins_user} 'https://192.168.1.12:8080/crumbIssuer/api/xml?xpath=concat(//crumbRequestField,":",//crumb)')
if [ ${#crumb} = 0 ]; then
    echo "ERR: Jenkinsのcrumb取得に失敗しました"
else
    echo "INFO: Jenkinsのcrumb取得に成功しました"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10001.xml)
jenkins_xml="CNB1AATB10001.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10001.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10001.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10002.xml)
jenkins_xml="CNB1AATB10002.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10002.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10002.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10003.xml)
jenkins_xml="CNB1AATB10003.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10003.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10003.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10004.xml)
jenkins_xml="CNB1AATB10004.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10004.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10004.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10005.xml)
jenkins_xml="CNB1AATB10005.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10005.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10005.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10006.xml)
jenkins_xml="CNB1AATB10006.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10006.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10006.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10007.xml)
jenkins_xml="CNB1AATB10007.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10007.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10007.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10008.xml)
jenkins_xml="CNB1AATB10008.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10008.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10008.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10009.xml)
jenkins_xml="CNB1AATB10009.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10009.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10009.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10010.xml)
jenkins_xml="CNB1AATB10010.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10010.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10010.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10011.xml)
jenkins_xml="CNB1AATB10011.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10011.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10011.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10012.xml)
jenkins_xml="CNB1AATB10012.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10012.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10012.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10013.xml)
jenkins_xml="CNB1AATB10013.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10013.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10013.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10014.xml)
jenkins_xml="CNB1AATB10014.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10014.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10014.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10015.xml)
jenkins_xml="CNB1AATB10015.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10015.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10015.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10016.xml)
jenkins_xml="CNB1AATB10016.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10016.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10016.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10017.xml)
jenkins_xml="CNB1AATB10017.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10017.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10017.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB10018.xml)
jenkins_xml="CNB1AATB10018.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB10018.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB10018.xml)"
fi

# -- ジョブ登録(xmlファイル:CNB1AATB19999.xml)
jenkins_xml="CNB1AATB19999.xml"
jenkins_dir="job/cnb1aatb1"
jenkins_jobname="${jenkins_xml%.*}"
result=`curl -k --user ${jenkins_user} -s -XPOST "https://192.168.1.12:8080/${jenkins_dir}/createItem?name=${jenkins_jobname}" --data-binary @${jenkins_xml} -H "$crumb" -H "Content-Type:text/xml"`
if [ $? != 0 ] || [ ${#result} != 0 ]; then
    echo "ERR: Jenkinsジョブ登録に失敗しました(xmlファイル:CNB1AATB19999.xml)"
else
    echo "INFO: Jenkinsジョブ登録に成功しました(xmlファイル:CNB1AATB19999.xml)"
fi
