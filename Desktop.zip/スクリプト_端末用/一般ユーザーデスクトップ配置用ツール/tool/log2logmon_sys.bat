
@echo off
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0log2logmon_sys.ps1"