
@echo off
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0winlogscheduler_auto.ps1"