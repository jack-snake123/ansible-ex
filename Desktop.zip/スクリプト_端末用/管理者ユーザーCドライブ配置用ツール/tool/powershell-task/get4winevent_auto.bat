@echo off
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0get4winevent_auto.ps1"