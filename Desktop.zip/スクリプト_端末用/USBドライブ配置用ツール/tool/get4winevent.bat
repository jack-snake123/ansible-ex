@echo off
PowerShell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0get4winevent.ps1"