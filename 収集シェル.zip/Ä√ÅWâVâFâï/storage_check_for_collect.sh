#!/bin/bash
function _StorageCheck() {
echo "df -hT"
df -hT
echo -e "\ndf -hiT"
df -hiT
echo -e "\nls -l /"
ls -l /
echo -e "\nsudo ls -lR /log/ /tool/ /serverlogbackup/"
sudo ls -lR /log/ /tool/ /serverlogbackup/
}

_StorageCheck | gzip > /tmp/storage_check-`hostname`_`date +"%Y%m%d%H%M%S"`.gz