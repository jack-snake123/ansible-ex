#!/bin/bash
function _StorageCheck() {
echo "df -hT"
df -hT
echo -e "\ndf -hiT"
df -hiT
echo -e "\nsudo ls -l / /log/"
sudo ls -l / /log/
echo -e "\nsudo ls -lR  /log/storage/ /log/linkage/ /log/torikomi/  /log/splunk_linkage/ /tool/ /serverlogbackup/"
sudo ls -lR  /log/storage/ /log/linkage/ /log/torikomi/  /log/splunk_linkage/ /tool/ /serverlogbackup/
echo -e "\nsudo tail -2000 /var/log/messages"
sudo tail -2000 /var/log/messages
echo -e "\nsudo tail -2000 /var/log/cron"
sudo tail -2000 /var/log/cron
}

_StorageCheck | gzip > /tmp/storage_check-`hostname`_`date +"%Y%m%d%H%M%S"`.gz