# 初期設定
import sys
import time
import ConfigParser
import datetime
import os

reload(sys)
reload(time)
reload(ConfigParser)

sys.setdefaultencoding("utf-8")
config = ConfigParser.ConfigParser()
config.read("C:\\sikuli\Webmail-test.sikuli\mailconf.txt")

mailbody_dir = 'C:\\sikuli\Webmail-test.sikuli\\'
mailbody_ptn = 'mailbody.txt_'

#### configファイルからID,PASSの読出し ###
user = config.get('userid', 'user')
pswd = config.get('userid', 'pass')
to = config.get('mail', 'to')
title = config.get('mail', 'title').decode('shift-jis')

# IE起動 
click("1569551770715.png")

wait("1569551811814.png",5)

#ウィンドウ最大化処理
if exists(Pattern("1569551869589.png").similar(0.85),5):
    wait(1)
    rightClick(Pattern("1569552271482.png").similar(0.85))
    wait(1)
    type("x")
    if exists(Pattern("1569821669947.png").similar(0.85),5):
        wait("1569823632720.png",5)
    else:
        rightClick(Pattern("1569552271482.png").similar(0.85))
        wait(1)
        type("x")
        wait("1569823632720.png",5)
else:
    if exists(Pattern("1569821669947.png").similar(0.85),5):
        wait("1569823632720.png",5)
    else:
        rightClick(Pattern("1569552271482.png").similar(0.85))
        wait(1)
        type("x")
        wait("1569823632720.png",5)

#TepcoMenu ログイン処理
click("1569551811814.png")

if exists("1569552370346.png",10):
    wait(1)
else: 
    click("1569551811814.png")
    wait("1569552370346.png",10)
paste("1569552420106.png", user)
wait(1)
paste("1569552429697.png", pswd)
wait(1)
click("1569552447322.png")

if exists("1569823198498.png",10):
    wait(1)
else: 
    click("1569552447322.png")
    wait("1569823198498.png",10)
    
#Webメールを開く
if exists("1569552647795.png",10):
    click("1569552647795.png")
    wait("1569823483651.png",10)
else: 
    click("1569552647795.png")
    wait("1569823483651.png",10)

if exists("1569823483651.png",10):
    click("1569823483651.png")
    wait("1569823564467.png",10)
else: 
    click("1569823483651.png")
    wait("1569823564467.png",10)

if exists("1569823564467.png",10):
    click("1569823564467.png")
    wait("1569823632720.png",5)
else: 
    click("1569823564467.png")
    wait("1569823632720.png",5)
    
if exists("1551338658279.png",10):
    wait(1)
else: 
    click("1569823632720.png")
    wait("1551338658279.png",10)

#メールを送る
#----- ディレクリ内ファイルやディレクトを全てリスト化
dir_list = os.listdir(mailbody_dir)
##----- 検索文字で抽出されたファイルやディレクトリ名をリスト化
mlbody_lst = [line for line in dir_list if mailbody_ptn in line]

for mlbody in mlbody_lst:
    with open(mailbody_dir+mlbody) as f:
        txt = f.read().decode('shift-jis')
    
    click("1551338658279.png")
    if exists("1551338706185.png",10):
        wait(1)
    else: 
        click("1551338658279.png")
        wait("1551338706185.png",10)

    paste(to)
    wait(1)
    type(Key.TAB*5)
    wait(1)
    paste(title)
    wait(1)
    paste("1551338753639.png", txt)
    wait(1)

    click("1551338706185.png")
    if exists("1551338658279.png",10):
        wait(1)
    else: 
        click("1551338706185.png")
        wait("1551338658279.png",10)

#IE終了処理
wait(1)
click("1569824090461.png")
if exists("1569823198498.png",10):
    wait(1)
else: 
    click("1569824090461.png")
    wait("1569823198498.png",10)
click("1569824301198.png")
if exists("1569552370346.png",10):
    wait(1)
else: 
    click("1569824301198.png")
    wait("1569552370346.png",10)
click("1569824200906.png")
