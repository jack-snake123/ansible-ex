#!/bin/sh

DATE=`date -d '10 minutes ago' '+%Y%m%d%H%M%S%3N'`
DATE2=`echo $DATE | sed -e 's/......$//'`
DATE3=`date -d '2 days ago' '+%Y%m%d%H%M%S%3N'`

##送信対象日付
echo "$DATE"

##送信対象日付整形
echo "$DATE2"

##削除対象日付
echo "$DATE3"

##削除対象選別一時ファイル生成
cat /tmp/jp1test/jp1mail.txt | sed -e 's/_.*$//g' > /tmp/jp1test/jp1maildel.txt

##2日前メッセージ削除処理
for i in `cat /tmp/jp1test/jp1maildel.txt`
do
  if [ `echo $i` -lt `echo $DATE3` ]; then
    sed -i "/$i\_/d" /tmp/jp1test/jp1mail.txt
  fi
done

##送信対象メッセージ抽出
cat /tmp/jp1test/jp1mail.txt | grep "$DATE2" | sed -e "s/^$DATE2......_//" > /tmp/jp1test/jp1mail2.txt
cat /tmp/jp1test/jp1mail.txt | grep "$DATE2" > /tmp/jp1test/jp1mail2_ori.txt
diff /tmp/jp1test/jp1mail.txt /tmp/jp1test/jp1mail2_ori.txt > /tmp/jp1test/diff.txt
cp /tmp/jp1test/diff.txt yml/

##送信処理
if [ "`cat /tmp/jp1test/jp1mail2.txt`" != "" ]; then
  ansible-playbook -i hosts/hosts yml/lstest-linux2.yml -vv --vault-password-file ~/ansible/.vault_password
  ansible-playbook -i hosts/hosts yml/testmail.yml -vv --vault-password-file ~/ansible/.vault_password
else
  echo "送信対象のメッセージはありませんでした。"
  cp /tmp/jp1test/jp1mail2.txt yml/
fi
