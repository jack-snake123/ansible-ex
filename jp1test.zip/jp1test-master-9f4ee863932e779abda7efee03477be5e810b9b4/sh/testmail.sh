#!/bin/sh

date

DATE2=`date -d '1 days ago' '+%Y%m%d'`
DATE0=`date '+%Y%m%d%H%M%S%3N'`
DATE1=`date -d '10 minutes ago' '+%Y%m%d%H%M%S%3N' | sed -e 's/......$//'`
JP1MESSAGE=`cat /jp1/message.txt /jp1/message.txt.${DATE2} | grep ^$DATE1`

#rm -rf /jp1/message.txt
#rm -rf /jp1/message.txt.${DATE2}

echo -n > /jp1/jp1mail.txt

while read line
do
  DATE=`echo ${line} | awk '{print$3$4}' | sed -e 's/\///g' | sed -e 's/://g' | sed -e 's/..$//g'`
  HOST=`echo ${line} | awk '{print$5}'`
  ID=`echo ${line} | awk '{print$2}'`
  MESSAGE=`echo ${line} | sed -e 's/^.*:0\ //'`

  sh/selectyml2.sh "$HOST" "$MESSAGE" "$ID" "$DATE" "$DATE0"
done << FILE
$JP1MESSAGE
FILE

date

sh/selectmail2.sh "$DATE0"
