#!/bin/sh

DATE=`date '+%Y%m%d%H%M%S%3N'`
DATE2=`echo "$DATE" | sed -e 's/......$/000/g'`
DATE3=`date -d '10 minutes ago' '+%Y%m%d%H%M%S%3N' | sed -e 's/......$/000/g'`

echo "B.ARRIVEDTIME TRANGE $DATE3 $DATE2" > /jp1/fil2.txt
echo "TIME" > /jp1/conf.txt
echo "ID" >> /jp1/conf.txt
echo "SOURCESERVER" >> /jp1/conf.txt
echo "MESSAGE" >> /jp1/conf.txt

/opt/jp1base/bin/jevexport -h h0064113 -o /jp1/csvconv.csv -l UTF-8 -t ON -f /jp1/fil2.txt -k /jp1/conf.txt
cat /jp1/csvconv.csv | grep -v -E "\"\"\,"$ > n

##改行コード整形
for LINE in `cat n`
do
  sed -i -z "s/$LINE \n/$LINE /g" /jp1/csvconv.csv
  sed -i -z "s/$LINE\n/$LINE /g" /jp1/csvconv.csv
done

##メッセージファイル整形
cat /jp1/csvconv.csv | awk -F , '{print$6 $12}' | sed -e 's/^\"//g' | sed -e 's/"$//g' | awk -F \"\" '{print$1" "$2}' | sed -e 's|^\(....\)\(..\)\(..\)\(..\)\(..\)\(..\)|\1/\2/\3 \4:\5:\6|g' > a
cat /jp1/csvconv.csv | awk -F \",\" '{print$5}' > b
cat /jp1/csvconv.csv | awk -F , '{print$2}' | sed 's/0*\([0-Z]*[0-Z]$\)/\1/g' | sed '/.*$/s/$/:0/g' | sed "/^.*/s/^/$DATE /g" > c

paste -d " " c a b > /jp1/csvconv.csv
rm -rf a b c n

#rm -rf /jp1/conf.txt /jp1/fil2.txt
