#!/bin/sh

date

DATE0=`date '+%Y%m%d%H%M%S%3N'`
JP1MESSAGE=`cat /jp1/message.txt`

#rm -rf /jp1/message.txt
echo -n > /jp1/jp1mail.txt

while read line
do
  DATE=`echo ${line} | awk '{print$3$4}' | sed -e 's/\///g' | sed -e 's/://g' | sed -e 's/..$//g'`
  HOST=`echo ${line} | awk '{print$5}'`
  ID=`echo ${line} | awk '{print$2}'`
  MESSAGE=`echo ${line} | sed -e 's/^.*:0\ //'`

  sh/selectyml3.sh "$HOST" "$ID" "$MESSAGE" "$DATE" "$DATE0"

done << FILE
$JP1MESSAGE
FILE

date

sh/selectmail3.sh $DATE0
