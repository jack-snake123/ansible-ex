#!/bin/sh
#set -x
######################################################################
#
#                                           by T.Ogata
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ1:IMPPRM〉
#　HOST名 EVENTID "KEYMESSAGE1" "KEYMESSAGE2" YML
#　h1b70041 * "*" "*" jp1mail_takusou01.yml
#　h1730042 * "h1b70041" "*" jp1mail_takusou01.yml
#　h1730042 * "message1" "message2" jp1mail_takusou01.yml
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ2:REIGAI.csv〉
#　HOST名 STARTTIME ENDTIME "KEYMESSAGE1" "KEYMESSAGE2"
#　h1b70159 201904171000 201904171100 "message1" "*"
#　h1b70159 201904171000 201904171100 "kernel: [Hardware Error]: Machine check events logged" "*"
#　h1b70051 201911151600 201912031300 "message1" "message2"
######################################################################
#　JP1取り込み情報
#  $1 = HOSTANME
#  $2 = JP1EVENTID
#  $3 = JP1MESSAGE
#  $4 = JP1STARTDATETIME
#  $5 = JP1SETTIME
######################################################################
INprm=`ls sh/nJP1IMPPRM`
INprm2=`ls sh/nJP1REIGAI.csv`

SETPRM1()
{
     PRM11=`echo ${LINE} | awk '{print$1}'`
     PRM12=`echo ${LINE} | awk '{print$2}'`
     PRM13=`echo ${LINE} | awk -F\" '{print$2}'`
     PRM14=`echo ${LINE} | awk -F\" '{print$4}'`
}

SETPRM2()
{
     PRM21=`echo ${LINE2} | awk '{print$1}'`
     PRM22=`echo ${LINE2} | awk '{print$2}'`
     PRM23=`echo ${LINE2} | awk '{print$3}'`
     PRM24=`echo ${LINE2} | awk -F\" '{print$2}'`
     PRM25=`echo ${LINE2} | awk -F\" '{print$4}'`
}

IFS='
'

##ホスト名入力有のチェック
for LINE in `cat ${INprm} | grep ^"$1"`
do
  SETPRM1
  echo "$2" | grep -E "${PRM12}" > /dev/null 2>&1
  if [ $? = 0 ]
    then
    if [ "${PRM13}" != "*" ]
      then
      echo "$3" | grep -F "${PRM13}" > /dev/null 2>&1
      if [ $? = 0 ]
        then
        if [ "${PRM14}" != "*" ]
          then
          echo "$3" | grep -F "${PRM14}" > /dev/null 2>&1
          if [ $? = 0 ]
            then
            FLAG=1
          else
            #echo "対応不要イベントです。"
            exit 0
          fi
        else
          FLAG=1
        fi
      else
        #echo "対応不要イベントです。"
        exit 0
      fi
    else
      FLAG=1
    fi
  else
    #echo "対応不要イベントです。"
    exit 0
  fi
done

##ホスト名入力無のチェック
for LINE in `cat ${INprm} | grep ^"*"`
do
  SETPRM1
  echo "$2" | grep -E "${PRM12}" > /dev/null 2>&1
  if [ $? = 0 ]
    then
    if [ "${PRM13}" != "*" ]
      then
      echo "$3" | grep -F "${PRM13}" > /dev/null 2>&1
      if [ $? = 0 ]
        then
        if [ "${PRM14}" != "*" ]
          then
          echo "$3" | grep -F "${PRM14}" > /dev/null 2>&1
          if [ $? = 0 ]
            then
            FLAG=1
          else
            #echo "対応不要イベントです。"
            exit 0
          fi
        else
          FLAG=1
        fi
      else
        #echo "対応不要イベントです。"
        exit 0
      fi
    else
      FLAG=1
    fi
  else
    #echo "対応不要イベントです。"
    exit 0
  fi
done

##除外リストのチェック
if [ "$FLAG" == "1" ]
  then
  ##ホスト名入力有のチェック
  for LINE2 in `cat ${INprm2} | grep ^"$1"`
    do
    SETPRM2
    if [ ${4} -ge ${PRM22} ]
      then
      if [ ${4} -lt ${PRM23} ]
        then
        if [ "${PRM24}" != "*" ]
          then
          echo "$3" | grep -F "${PRM24}" > /dev/null 2>&1
          if [ $? = 0 ]
            then
            if [ "${PRM25}" != "*" ]
              then
              echo "$3" | grep -F "${PRM25}" > /dev/null 2>&1
              if [ $? = 0 ]
                then
                #echo "非監視イベントです。"
                exit 0
              fi
            else
              #echo "非監視イベントです。"
              exit 0
            fi
          fi
        else
          if [ "${PRM25}" != "*" ]
            then
            echo "$3" | grep -F "${PRM25}" > /dev/null 2>&1
            if [ $? = 0 ]
              then
              #echo "非監視イベントです。"
              exit 0
            fi
          else
            #echo "非監視イベントです。"
            exit 0
          fi
        fi
      fi
    fi
  done

  ##ホスト名入力無のチェック
  for LINE2 in `cat ${INprm2} | grep ^"*"`
  do
    SETPRM2
    if [ ${4} -ge ${PRM22} ]
      then
      if [ ${4} -lt ${PRM23} ]
        then
        if [ "${PRM24}" != "*" ]
          then
          echo "$3" | grep -F "${PRM24}" > /dev/null 2>&1
          if [ $? = 0 ]
            then
            if [ "${PRM25}" != "*" ]
              then
              echo "$3" | grep -F "${PRM25}" > /dev/null 2>&1
              if [ $? = 0 ]
                then
                #echo "非監視イベントです。"
                exit 0
              fi
            else
              #echo "非監視イベントです。"
              exit 0
            fi
          fi
        else
          if [ "${PRM25}" != "*" ]
            then
            echo "$3" | grep -F "${PRM25}" > /dev/null 2>&1
            if [ $? = 0 ]
              then
              #echo "非監視イベントです。"
              exit 0
            fi
          else
            #echo "非監視イベントです。"
            exit 0
          fi
        fi
      fi
    fi
  done
else
  #echo "対応不要イベントです。"
  exit 0
fi

echo "$5"_"$3" >> /jp1/jp1mail.txt
exit 0
