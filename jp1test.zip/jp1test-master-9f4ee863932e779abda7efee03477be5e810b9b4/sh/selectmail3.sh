#!/bin/sh

echo -n > /jp1/jp1mail2_ori.txt
echo -n > /jp1/diff.txt
rm -rf > /jp1/jp1mail2.txt*
cp /jp1/jp1mail.txt /jp1/jp1mail2_ori.txt

##送信対象メッセージ抽出
cat /jp1/jp1mail.txt | grep "$1" | sed -e "s/^$1_//" > /jp1/jp1mail2.txt
int=`wc -l /jp1/jp1mail2.txt | awk '{print$1}'`
if [ $int -gt 14000 ]; then
  echo "jevsend 14000 over"
fi
#diff /jp1/jp1mail.txt /jp1/jp1mail2_ori.txt > /jp1/diff.txt

##成果物取得
cp /jp1/diff.txt ./yml/
cp /jp1/jp1mail.txt ./yml/

##送信処理
if [ "`cat /jp1/jp1mail2.txt`" != "" ]; then
  rm -rf /jp1/jp1mail2.txt_*
  split -l 1000 -d /jp1/jp1mail2.txt /jp1/jp1mail2.txt_
  No=00
  while test -f /jp1/jp1mail2.txt_${No}
  do
    ansible-playbook -i hosts/hosts yml/lstest-linux5.yml -vv --extra-vars "No=${No}" --vault-password-file ~/ansible/.vault_password
    #ansible-playbook -i hosts/hosts yml/testmail.yml -vv --extra-vars "No=${No}" --vault-password-file ~/ansible/.vault_password
    No=`expr $No + 1`
    No=`printf %02d $No`
  done
  #ansible-playbook -i hosts/hosts yml/testmail.yml -vv --extra-vars --vault-password-file ~/ansible/.vault_password
else
  echo "送信対象のメッセージはありませんでした。"
  cp /jp1/jp1mail2.txt ./yml/
fi
