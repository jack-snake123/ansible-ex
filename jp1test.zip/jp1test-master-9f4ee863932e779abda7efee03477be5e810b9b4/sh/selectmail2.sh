#!/bin/sh

echo -n > /jp1/jp1mail2_ori.txt
cp /jp1/jp1mail.txt /jp1/jp1mail2_ori.txt

##送信対象メッセージ抽出
cat /jp1/jp1mail.txt | grep "$1" | sed -e "s/^$1_//" > /jp1/jp1mail2.txt
diff /jp1/jp1mail.txt /jp1/jp1mail2_ori.txt > /jp1/diff.txt

##成果物取得
cp /jp1/diff.txt ../yml/
cp /jp1/jp1mail.txt ../yml/

##送信処理
if [ "`cat /jp1/jp1mail2.txt`" != "" ]; then
  ansible-playbook -i hosts/hosts yml/lstest-linux2.yml -vv --vault-password-file ~/ansible/.vault_password
#  ansible-playbook -i hosts/hosts yml/testmail.yml -vv --vault-password-file ~/ansible/.vault_password
else
  echo "送信対象のメッセージはありませんでした。"
fi
