#!/bin/sh
#set -x
######################################################################
#
#                                           by T.Ogata
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ1:IMPPRM〉
#　HOST名 KEYMESSAGE EVENTID YML
#　h1130045 ORA-11111 1F40:0 jp1action1.yml
#　h1130045 * * jp1action2.yml
#　* "message message message" * jp1action3.yml
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ2:REIGAI.csv〉
#　HOST名 STARTTIME ENDTIME MESSAGE
#　h1130045 201904010000 201904012359 message
#　h1130046 201904010000 202004010000 message
#　h1130047 201904010000 209904012359 "message message message"
######################################################################
#　JP1取り込み情報
#  $1 = HOSTANME
#  $2 = JP1MESSAGE
#  $3 = JP1EVENTID
#  $4 = JP1START-ENDTIME
#  $5 = DATE0=TIMESTAMP
######################################################################
INprm=`ls sh/*IMPPRM`
INprm2=`ls sh/*REIGAI.csv`

JP1DATE=`echo "$4"`
JP1DATE2=`echo "$5"`

SETPRM1()
{
     PRM1=`echo ${LINE} | awk '{print$1}'`
     if [ "`echo ${LINE} | awk '{print$2}' | cut -c 1-1`" = \" ]
       then
       PRM2=`echo ${LINE} | sed 's/^.*"\(.*\)".*$/\1/'`
       PRM10=1
     else
       PRM2=`echo ${LINE} | awk '{print$2}'`
       PRM10=0
     fi
     PRM3=`echo ${LINE} | awk '{print$(NF-1)}'`
     PRM4=`echo ${LINE} | awk '{print$NF}'`
}

SETPRM2()
{
     PRM5=`echo ${LINE2} | awk '{print$1}'`
     PRM6=`echo ${LINE2} | awk '{print$2}'`
     PRM7=`echo ${LINE2} | awk '{print$3}'`
     if [ "`echo ${LINE2} | awk '{print$4}' | cut -c 1-1`" = \" ]
       then
       PRM8=`echo ${LINE2} | sed 's/^.*"\(.*\)"/\1/'`
       PRM9=1
     else
       PRM8=`echo ${LINE2} | awk '{print$4}'`
       PRM9=0
     fi
}

IFS='
'

for LINE in `cat ${INprm} | grep ^"$1"`
do
     SETPRM1
       if [ `echo ${PRM10}` = "0" ]
         then
         echo "$2" | grep -E "${PRM2}" > /dev/null 2>&1
         if [ $? = 0 ]
           then
           echo "$3" | grep -E "${PRM3}" > /dev/null 2>&1
           if [ $? = 0 ]
             then
             case "${PRM4}" in
             *)
             for LINE2 in `cat ${INprm2} | grep ^"$1"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             for LINE2 in `cat ${INprm2} | grep ^"*"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             echo "$JP1DATE2"_"$2" >> /jp1/jp1mail.txt
             exit 0
             ;;
             esac
           fi
         fi
       else
         echo "$2" | grep -F "${PRM2}" > /dev/null 2>&1
         if [ $? = 0 ]
           then
           echo "$3" | grep -E "${PRM3}" > /dev/null 2>&1
           if [ $? = 0 ]
             then
             case "${PRM4}" in
             *)
             for LINE2 in `cat ${INprm2} | grep ^"$1"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             for LINE2 in `cat ${INprm2} | grep ^"*"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             echo "$JP1DATE2"_"$2" >> /jp1/jp1mail.txt
             exit 0
             ;;
             esac
           fi
         fi
       fi
done

for LINE in `cat ${INprm} | grep ^"*"`
do
     SETPRM1
       if [ `echo ${PRM10}` = "0" ]
         then
         echo "$2" | grep -E "${PRM2}" > /dev/null 2>&1
         if [ $? = 0 ]
           then
           echo "$3" | grep -E "${PRM3}" > /dev/null 2>&1
           if [ $? = 0 ]
             then
             case "${PRM4}" in
             *)
             for LINE2 in `cat ${INprm2} | grep ^"$1"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             for LINE2 in `cat ${INprm2} | grep ^"*"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             echo "$JP1DATE2"_"$2" >> /jp1/jp1mail.txt
             exit 0
             ;;
             esac
           fi
         fi
       else
         echo "$2" | grep -F "${PRM2}" > /dev/null 2>&1
         if [ $? = 0 ]
           then
           echo "$3" | grep -E "${PRM3}" > /dev/null 2>&1
           if [ $? = 0 ]
             then
             case "${PRM4}" in
             *)
             for LINE2 in `cat ${INprm2} | grep ^"$1"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             for LINE2 in `cat ${INprm2} | grep ^"*"`
             do
               SETPRM2
               if [ ${JP1DATE} -ge ${PRM6} ]
                 then
                 if [ ${JP1DATE} -lt ${PRM7} ]
                   then
                   if [ `echo ${PRM9}` = "0" ]
                     then
                     echo "$2" | grep -E "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   else
                     echo "$2" | grep -F "${PRM8}" > /dev/null 2>&1
                     if [ $? = 0 ]
                       then
                       echo "非監視イベントです。"
                       exit 0
                     fi
                   fi
                 fi
               fi
             done
             echo "$JP1DATE2"_"$2" >> /jp1/jp1mail.txt
             exit 0
             ;;
             esac
           fi
         fi
       fi
done
#echo "対応不要イベントです。"
exit 0
