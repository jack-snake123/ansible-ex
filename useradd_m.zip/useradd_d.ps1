$idlist = (Get-Content idlist_m.txt) -as [string[]]
$namelist = (Get-Content namelist_m.txt) -as [string[]]
$i=1

foreach ($d in $idlist) {
  foreach ($n in $namelist) {
    $id = $i : $d
    $name = $i : $n

    New-LocalUser -Name $id -Password (ConvertTo-SecureString "$id" -AsPlainText -Force) -FullName "$name"
    Add-LocalGroupMember -Group "Users" -Member $id
    Add-LocalGroupMember -Group "Remote Desktop Users" -Member $id

    $i++
  }
}
