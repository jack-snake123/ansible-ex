#!/bin/sh

#
# コミュニティ名
COMMUNITY="realdev"

#
# ログファイルディレクリ
#LOGDIR="/test/log/snmp_log"
LOGDIR="/infraunyo/snmp/log"

# トレースログファイルディレクリ_大廣
LOGDIR2="/infraunyo/snmp/log2"

#
# ログファイル
LOG_STD="standard.log"
LOG_ENT="enterprise.log"
# トレースログファイル_大廣
LOG_TRACE="trace_log_`date '+%Y%m%d'`.log"

#
# snmpwalk失敗時のリトライ回数
RETRY_CNT=3

#
# snmpwalkタイムアウト値(1=10秒)
WALK_TIMEOUT=0.3

#
# 取得対象NW
NWLIST="/infraunyo/snmp/config/snmp.config"
#NWLIST="/test/work_snmp.config"

#
# INDEX-PORT OID
INDEXOID="1.3.6.1.2.1.2.2.1.2"
#IFOID="1.3.6.1.2.1.2.2.1.2."

#
# MACHINE OID
MACHINEOID="1.3.6.1.2.1.1.5.0"

#
# 収集対象 OID (STANDARD)
OIDLIST_STD=(\
"1.3.6.1.2.1.2.2.1.5" \
"1.3.6.1.2.1.31.1.1.1.6" \
"1.3.6.1.2.1.31.1.1.1.10" \
"1.3.6.1.2.1.2.2.1.14" \
"1.3.6.1.2.1.2.2.1.20" \
"1.3.6.1.2.1.2.2.1.13" \
"1.3.6.1.2.1.2.2.1.19" \
"1.3.6.1.2.1.31.1.1.1.15" \
"1.3.6.1.2.1.2.2.1.7" \
"1.3.6.1.2.1.2.2.1.8" \
)
#1.3.6.1.2.1.2.2.1.5 ,ifSpeed
#1.3.6.1.2.1.31.1.1.1.15 ,ifHiSpeed
#1.3.6.1.2.1.31.1.1.1.6 ,ifHCInOctets
#1.3.6.1.2.1.31.1.1.1.10 ,ifHCOutOctets
#1.3.6.1.2.1.2.2.1.14 ,ifInErrors
#1.3.6.1.2.1.2.2.1.20 ,ifOutErrors
#1.3.6.1.2.1.2.2.1.13 ,ifInDiscards
#1.3.6.1.2.1.2.2.1.19 ,ifOutDiscards
#1.3.6.1.2.1.2.2.1.7 ,ifAdminStatus
#1.3.6.1.2.1.2.2.1.8 ,ifOperStatus

#
# 収集対象 OID (ENTERPRISE)
OIDLIST_ENT=(\
"1.3.6.1.4.1.9.9.305.1.1.1.0","CPUUtilization" \
"1.3.6.1.4.1.9.9.305.1.1.2.0","MEMUtilization" \
"1.3.6.1.4.1.9.9.221.1.1.1.1.7.22.1","MEMPoolUsed" \
"1.3.6.1.4.1.9.9.221.1.1.1.1.8.22.1","MEMPoolFree" \
"1.3.6.1.4.1.9.9.305.1.1.10.0","SysUpTime" \
)

#1.3.6.1.4.1.9.9.305.1.1.1.0 ,CPUUtilization
#1.3.6.1.4.1.9.9.305.1.1.2.0 ,MEMUtilization
#1.3.6.1.4.1.9.9.221.1.1.1.1.7.22.1 ,MEMPoolUsed
#1.3.6.1.4.1.9.9.221.1.1.1.1.8.22.1 ,MEMPoolFree
#1.3.6.1.4.1.9.9.305.1.1.10.0 ,SysUpTime


#
#90日前のログファイル削除_大廣
find ${LOGDIR2} -maxdepth 1 -mindepth 1 -type f -mtime +90 -exec rm -f {} \;

#
# ログディレクトリがなければ作成する
if [ ! -d ${LOGDIR} ]; then
    # 存在しない場合は作成（本処理へ)
    mkdir -p ${LOGDIR}
fi

#
# トレースログディレクトリがなければ作成する
if [ ! -d ${LOGDIR2} ]; then
    # 存在しない場合は作成（本処理へ)
    mkdir -p ${LOGDIR2}
fi

#
# ログファイルがなければ作成する
if [ ! -e ${LOGDIR}"/"${LOG_STD} ];then
   #echo "File not exists."
   touch ${LOGDIR}"/"${LOG_STD}
fi

#
# ログファイルがなければ作成する
if [ ! -e ${LOGDIR}"/"${LOG_ENT} ];then
   #echo "File not exists."
   touch ${LOGDIR}"/"${LOG_ENT}
fi

#
# トレースログファイルがなければ作成する_大廣
if [ ! -e ${LOGDIR2}"/"${LOG_TRACE} ];then
   #echo "File not exists."
   touch ${LOGDIR2}"/"${LOG_TRACE}
fi


#
# 収集対象 OID (STANDARD)とOID名の紐づけ 
for ((i = 0; i < ${#OIDLIST_STD[@]}; i++)) {
    OIDNAME=`snmptranslate ${OIDLIST_STD[$i]} | awk -F "::" '{print $2}'`
    OIDLIST_STD_+=("${OIDLIST_STD[$i]}":"${OIDNAME}")
}

#
# 本処理
# NW機器毎に実施（取得対象のNW機器のIPが記載された外部パラメータを読み込み処理する）
while IFS=,  read IP KEI
do
    WALK_STATUS=0
    for x in `seq 0 ${RETRY_CNT}`; do
        MACHINE_NAME=`snmpwalk -v 2c -c ${COMMUNITY} -t ${WALK_TIMEOUT} ${IP} ${MACHINEOID} | awk -F "STRING: " '{print $2}'`
        # -- snmpwalkでエラーした場合、loopの先頭に戻る
        if [ "${MACHINE_NAME}" = "" ] && [ ${x} -eq  ${RETRY_CNT} ]; then
            WALK_STATUS=1
        elif [ "${MACHINE_NAME}" != "" ]; then
            echo "`date '+%Y/%m/%d %H:%M:%S'` ${MACHINE_NAME} SNMPWALK処理開始">> ${LOGDIR2}"/"${LOG_TRACE}
            break
        else
            echo "${0##*/}: WARNING: ${IP}に対するsnmpwalkコマンドに失敗したため再処理します(リトライ回数:$((x + 1))/${RETRY_CNT})" >&2
            #終了時間取得_大廣
            echo "`date '+%Y/%m/%d %H:%M:%S'` ${MACHINE_NAME} リトライ${RETRY_CNT})" >> ${LOGDIR2}"/"${LOG_TRACE}
        fi
    done

    # snmppwalkでマシン名が取れない場合は該当機器は処理をスキップする
    if [ ${WALK_STATUS} -eq 1 ]; then
        echo "${0##*/}: ERROR: ${IP}に対するsnmpwalkコマンドに失敗したため処理をスキップします" >&2
        continue
    fi

    INDEXS_SUMMARY=`snmpwalk -v 2c -c ${COMMUNITY} -t ${WALK_TIMEOUT} ${IP} ${INDEXOID} | cut -f 2 -d "." | cut -f 1,4 -d " "`


    # 各OID（standard）のsnmpwalk結果を連想配列（RESULT_DICT_STD）に格納 { oidname : snmpwalk結果 }
    declare -A _RESULT_DICT_STD_
    for _OID in "${OIDLIST_STD_[@]}"; do
        OID=`echo $_OID | cut -f 1 -d ":"`
        OIDNAME=`echo $_OID | cut -f 2 -d ":"` 
        
        # SNMPWALK実行
        _RESULT_DICT_STD_[${OIDNAME}]=`snmpwalk -v 2c -c ${COMMUNITY} -t ${WALK_TIMEOUT} ${IP} ${OID}`
    done


    # port毎にOIDの取得結果を連想配列（_SUMMARY_BY_PORT_）に格納 { oidname : snmpwalk結果 }
    declare -A _SUMMARY_BY_PORT_
    echo "$INDEXS_SUMMARY" | while read MACHINE_INDEX MACHINE_PORT ; do

        # 各OIDのsnmapwalk結果を格納した連想配列（_RESULT_DICT_STD_）から対象portの値を連想配列（_SUMMARY_BY_PORT_）に格納
        for KEY in "${!_RESULT_DICT_STD_[@]}"; do

            VALUE=`echo -e "${_RESULT_DICT_STD_[${KEY}]}" | grep -e "${KEY}.${MACHINE_INDEX} = Counter" | awk -F "Counter64: " '{print $2}'`
           
            if [ -z "${VALUE}" ]; then
                VALUE=`echo -e "${_RESULT_DICT_STD_[${KEY}]}" | grep -e "${KEY}.${MACHINE_INDEX} = Counter" | awk -F "Counter32: " '{print $2}'`

		        if [ -z "${VALUE}" ]; then
		            VALUE=`echo -e "${_RESULT_DICT_STD_[${KEY}]}" | grep -e "${KEY}.${MACHINE_INDEX} = Gauge" | awk -F "Gauge32: " '{print $2}'`

                    if [ -z "${VALUE}" ]; then
                        VALUE=`echo -e "${_RESULT_DICT_STD_[${KEY}]}" | grep -e "${KEY}.${MACHINE_INDEX} = Gauge" | awk -F "Gauge64: " '{print $2}'`

                      if [ -z "${VALUE}" ]; then
                        VALUE=`echo -e "${_RESULT_DICT_STD_[${KEY}]}" | grep -e "${KEY}.${MACHINE_INDEX} = INTEGER" | awk -F "INTEGER: " '{print $2}'`
                      fi

                        if [ -z "${VALUE}" ]; then
                            VALUE="NULL"
                        fi
                    fi    
		        fi               
            fi

            # _SUMMARY_BY_PORT_={ oidname : snmpwalk結果 } 
            _SUMMARY_BY_PORT_[${KEY}]=${VALUE}
        done


        # 収集対象として定義したOID配列の順にログファイルに書き込む 
        echo -n `date '+%Y/%m/%d %H:%M:%S'`,${MACHINE_NAME},${KEI},${IP},${MACHINE_INDEX},${MACHINE_PORT}, >> ${LOGDIR}"/"${LOG_STD}
        i=1
        for _OID in "${OIDLIST_STD_[@]}"; do
            OID=`echo $_OID | cut -f 1 -d ":"`
            OIDNAME=`echo $_OID | cut -f 2 -d ":"`

            if [ "${#_SUMMARY_BY_PORT_[@]}" -gt "${i}" ]; then
                echo -n "${OIDNAME}":"${_SUMMARY_BY_PORT_[${OIDNAME}]}", >> ${LOGDIR}"/"${LOG_STD}
            else
                echo "${OIDNAME}":"${_SUMMARY_BY_PORT_[${OIDNAME}]}" >> ${LOGDIR}"/"${LOG_STD}
            fi
            i=`expr $i + 1`
        done

    done

    unset _RESULT_DICT_STD_
    unset _SUMMARY_BY_PORT_

    # 各OID（enterprise）のsnmpwalk結果を連想配列（_RESULT_DICT_ENT_）に格納 { oidname : snmpwalk結果 }
    declare -A _RESULT_DICT_ENT_
    for _OID in "${OIDLIST_ENT[@]}"; do
        OID=`echo $_OID | cut -f 1 -d ","`
        OIDNAME=`echo $_OID | cut -f 2 -d ","`
        
        # SNMPWALK実行
        _RESULT_DICT_ENT_[${OIDNAME}]=`snmpwalk -v 2c -c ${COMMUNITY} -t ${WALK_TIMEOUT} ${IP} ${OID}`
    done

    # 機器毎にOIDの取得結果を連想配列（_SUMMARY_BY_MACHINE_）に格納 { oidname : snmpwalk結果 }
    declare -A _SUMMARY_BY_MACHINE_
    for KEY in "${!_RESULT_DICT_ENT_[@]}"; do

        VALUE=`echo -e "${_RESULT_DICT_ENT_[${KEY}]}" | awk -F "Gauge32: " '{print $2}'`

        if [ -z "${VALUE}" ]; then
            VALUE=`echo -e "${_RESULT_DICT_ENT_[${KEY}]}" | awk -F "Gauge64: " '{print $2}'`

            if [ -z "${VALUE}" ]; then
                VALUE=`echo -e "${_RESULT_DICT_ENT_[${KEY}]}" | awk -F "Counter64: " '{print $2}'`

                if [ -z "${VALUE}" ]; then
                    VALUE=`echo -e "${_RESULT_DICT_ENT_[${KEY}]}" | awk -F "Counter32: " '{print $2}'`

                    if [ -z "${VALUE}" ]; then
                        VALUE="NULL"
                    fi
                fi 
            fi
        fi

        # _SUMMARY_BY_PORT_={ oidname : snmpwalk結果 } 
        _SUMMARY_BY_MACHINE_[${KEY}]=${VALUE}
    done

    #終了時間取得_大廣
    echo "`date '+%Y/%m/%d %H:%M:%S'` ${MACHINE_NAME} SNMPWALK処理終了" >> ${LOGDIR2}"/"${LOG_TRACE}

    # 収集対象として定義したOID配列の順にログファイルに書き込む
    echo -n `date '+%Y/%m/%d %H:%M:%S'`,${MACHINE_NAME},${KEI},${IP}, >> ${LOGDIR}"/"${LOG_ENT}
    k=1
    for _OID in "${OIDLIST_ENT[@]}"; do
        OIDNAME=`echo $_OID | cut -f 2 -d ","`

        if [ "${#_SUMMARY_BY_MACHINE_[@]}" -gt "${k}" ]; then
            echo -n "${OIDNAME}":"${_SUMMARY_BY_MACHINE_[${OIDNAME}]}", >> ${LOGDIR}"/"${LOG_ENT}
        else
            echo "${OIDNAME}":"${_SUMMARY_BY_MACHINE_[${OIDNAME}]}" >> ${LOGDIR}"/"${LOG_ENT}
        fi
        k=`expr $k + 1`
    done

    #終了時間取得_大廣
    echo "`date '+%Y/%m/%d %H:%M:%S'` ${MACHINE_NAME} ログファイル書込処理終了" >> ${LOGDIR2}"/"${LOG_TRACE}
    unset _RESULT_DICT_ENT_
    unset _SUMMARY_BY_MACHINE_

done < ${NWLIST}
#echo "end."
