#!/bin/sh

DATE=`date '+%Y%m%d%H%M%S%3N'`
DATE2=`echo "$DATE" | sed -e 's/......$/000/g'`
DATE3=`date -d '1 days ago' '+%Y%m%d%H%M%S%3N' | sed -e 's/......$/000/g'`

echo "B.ARRIVEDTIME TRANGE $DATE3 $DATE2" > ../jp1/fil2.txt
echo "TIME" > ../jp1/conf.txt
echo "ID" >> ../jp1/conf.txt
echo "SOURCESERVER" >> ../jp1/conf.txt
echo "MESSAGE" >> ../jp1/conf.txt

#/opt/jp1base/bin/jevexport -h h0064113 -o ../jp1/csvconv.csv -l UTF-8 -t ON -f ../jp1/fil2.txt -k ../jp1/conf.txt