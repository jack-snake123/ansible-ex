#!/usr/bin/env python
# -*- coding: utf-8 -*-

import csv, re
from datetime import datetime
from argparse import ArgumentParser

# -- �ᥤ�����
try:
    # -- �ѿ����å�
    rc = 0
    hscript = 'yiccodef'
    out_dict = []
    err_dict = []
    sav_year = 5

    # -- ���ռ���
    exec_date = datetime.now()

    # -- CSV�ѥإå�������
    rhedder = ['hst_name','jpn_name','ip_addr','aply_date','col_time_cd','log_ctg_cd','log_dir','log_name','sav_year',
               'srv_place','entry_srv','entry_sh','time_stamp','seq_value']
    whedder = ['ip_addr','hst_name','jpn_name','aply_date','col_time_cd','log_ctg_cd','log_dir','log_name','sav_year',
               'srv_place','entry_srv','entry_sh','time_stamp','seq_value']

    # -- ���ץ��������å�
    if __name__ == '__main__':
        parser = ArgumentParser()
        parser.add_argument('-i', '--input', type=str, help='InputFile(Path)')
        parser.add_argument('-o', '--output', type=str, help='OutputFile(Path)')
        parser.add_argument('-e', '--erroutput', type=str, help='ErrOutputFile(Path)')
        parser.add_argument('-s', '--startid', type=int, help='Start DB IndexID')
        args = parser.parse_args()
        infile = args.input
        outfile = args.output
        errfile = args.erroutput
        dbid = args.startid

    # -- �ե������ɹ���
    with open(infile, 'rt') as rf:
        dict_reader = csv.DictReader(rf, fieldnames=rhedder, delimiter=' ')
        tmp_dict = [ r for r in dict_reader ]

    # -- re�ѥ����󥻥å�
    ip_ptn = r'^(([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([1-9]?[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$'
    ymd_ptn = r'^[1-9][0-9][0-9][0-9][0-1][0-9][0-3][0-9]$'
    char_ptn = r'^[A-Z]$'

    # -- �쥳���ɥ��å�
    for i in range(len(tmp_dict)):
        
        # -- IP���ɥ쥹�Υ����å�
        if not re.match(ip_ptn, tmp_dict[i]['ip_addr']):
            #print('Invalid ip_addr:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- aply_date�Υ����å�
        if not re.match(ymd_ptn, tmp_dict[i]['aply_date']):
            #print('Invalid make_date:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- log_ctg_cd�Υ����å�
        if not re.match(char_ptn, tmp_dict[i]['log_ctg_cd']):
            #print('Invalid log_ctg_cd:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(512char)
        if tmp_dict[i]['log_dir'] and len(tmp_dict[i]['log_dir']) > 512:
            #print('Invalid log_dir over 512char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        if tmp_dict[i]['log_name'] and len(tmp_dict[i]['log_name']) > 2048:
            #print('Invalid log_name over 2048char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(128char)
        if tmp_dict[i]['srv_place'] and len(tmp_dict[i]['srv_place']) > 128:
            #print('Invalid srv_place over 128char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(96char)
        if tmp_dict[i]['jpn_name'] and len(tmp_dict[i]['jpn_name']) > 96:
            #print('Invalid jpn_name over 96char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(20char)
        if tmp_dict[i]['entry_sh'] and len(tmp_dict[i]['entry_sh']) > 20:
            #print('Invalid entry_sh over 20char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(15char)
        if tmp_dict[i]['ip_addr'] and len(tmp_dict[i]['ip_addr']) > 20:
            #print('Invalid ip_addr over 15char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(8char)
        if tmp_dict[i]['entry_srv'] and len(tmp_dict[i]['entry_srv']) > 8:
            #print('Invalid entry_srv over 8char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ݴ�ǯ�������å������å�
        if not tmp_dict[i]['sav_year']:
            tmp_dict[i]['sav_year'] = sav_year

        tmp_dict[i]['entry_sh'] = hscript
        tmp_dict[i]['time_stamp'] = exec_date
        tmp_dict[i]['seq_value'] = dbid
        out_dict.append(tmp_dict[i])
        dbid += 1

    # -- DB������CSV����
    with open(outfile, 'wt') as wf:
        dict_writer = csv.DictWriter(wf, fieldnames=whedder, extrasaction='ignore')

        dict_writer.writeheader()
        dict_writer.writerows(out_dict)

    # -- ���顼CSV����
    if err_dict:
        with open(errfile, 'wt') as wfe:
            dict_writer = csv.DictWriter(wfe, fieldnames=whedder, extrasaction='ignore')

            dict_writer.writeheader()
            dict_writer.writerows(err_dict)

except Exception as e:
    print(e)
    rc = 99
except ValueError as e:
    print(e)
    rc = 9
finally:
    print('nextdbid:'+str(dbid))
    exit(rc)
