#!/usr/bin/env python
# -*- coding: utf-8 -*-

import csv, re
from datetime import datetime
from dateutil.relativedelta import relativedelta
from argparse import ArgumentParser

# -- �ݴɴ��»��Х��饹
class calcsavedate:
    # -- ���󥹥����ѿ����
    stadate = None
    saveyear = None

    # -- get�᥽�å����
    def get(data):
        tdate =  datetime.strptime(data.stadate, '%Y%m%d')
        savedate = tdate + relativedelta(years=data.saveyear)
        return(savedate.strftime('%Y%m%d'))

    # -- output�᥽�å����
    def output(data):
        tdate =  datetime.strptime(data.stadate, '%Y%m%d')
        savedate = tdate + relativedelta(years=data.saveyear)
        print(savedate.strftime('%Y%m%d'))

# -- �ᥤ�����
try:
    # -- �ѿ����å�
    rc = 0
    hscript = 'yisdata'
    out_dict = []
    err_dict = []

    # -- ���ռ���
    exec_date = datetime.now()

    # -- CSV�ѥإå�������
    rhedder = ['hst_name', 'log_ctg_cd', 'make_date', 'ctg_dir', 'log_name', 'col_sts_cd', 'gomi_colmn', 'ctg_dirsv',
              'col_time_cd', 'sav_day', 'log_sz', 'srv_place', 'entry_srv', 'entry_sh', 'time_stamp', 'seq_value']
    whedder = ['hst_name', 'log_ctg_cd', 'col_time_cd', 'make_date', 'ctg_dir', 'ctg_dirsv', 'log_name',
               'col_sts_cd', 'sav_day', 'log_sz', 'srv_place', 'entry_srv', 'entry_sh', 'time_stamp', 'seq_value']

    # -- ���ץ��������å�
    if __name__ == '__main__':
        parser = ArgumentParser()
        parser.add_argument('-i', '--input', type=str, help='InputFile(Path)')
        parser.add_argument('-o', '--output', type=str, help='OutputFile(Path)')
        parser.add_argument('-e', '--erroutput', type=str, help='ErrOutputFile(Path)')
        parser.add_argument('-d', '--dc', type=str, help='Input DC(SDC or CDC)')
        parser.add_argument('-s', '--startid', type=int, help='Start DB IndexID')
        args = parser.parse_args()
        infile = args.input
        outfile = args.output
        errfile = args.erroutput
        dc = args.dc
        dbid = args.startid

    # -- DC�����å�
    if dc.upper() == 'SDC':
        repf_dir = '/SDC_YI_M'
        rept_dir = '/SDC_YI_S'
    elif dc.upper() == 'CDC':
        repf_dir = '/CDC_YI_M'
        rept_dir = '/CDC_YI_S'
    else:
        raise ValueError(u'error: dc error')

    # -- �ե������ɹ���
    with open(infile, 'rt') as rf:
        dict_reader = csv.DictReader(rf, fieldnames=rhedder)
        tmp_dict = [ r for r in dict_reader ]

    # -- �ݴɴ��ֻ��Х��饹������
    getsdate = calcsavedate()
    getsdate.saveyear = 5

    # -- �ݴɴ��֥��å�
    for i in range(len(tmp_dict)):
        ymd_ptn = r'^[1-9][0-9][0-9][0-9][0-1][0-9][0-3][0-9]$'
        char_ptn = r'^[A-Z]$'
        
        # -- make_date�Υ����å�
        if re.match(ymd_ptn, tmp_dict[i]['make_date']):
            getsdate.stadate = tmp_dict[i]['make_date']
            tmp_dict[i]['sav_day'] = getsdate.get()
        else:
            #print('Invalid make_date:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- log_ctg_cd�Υ����å�
        if not re.match(char_ptn, tmp_dict[i]['log_ctg_cd']):
            #print('Invalid log_ctg_cd:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(512char)
        if tmp_dict[i]['ctg_dir'] and len(tmp_dict[i]['ctg_dir']) > 512:
            #print('Invalid ctg_dir over 512char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        if tmp_dict[i]['ctg_dirsv'] and len(tmp_dict[i]['ctg_dirsv']) > 512:
            #print('Invalid ctg_dirsv over 512char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        if tmp_dict[i]['log_name'] and len(tmp_dict[i]['log_name']) > 2048:
            #print('Invalid log_name over 2048char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(128char)
        if tmp_dict[i]['srv_place'] and len(tmp_dict[i]['srv_place']) > 128:
            #print('Invalid srv_place over 128char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(20char)
        if tmp_dict[i]['entry_sh'] and len(tmp_dict[i]['entry_sh']) > 20:
            #print('Invalid entry_sh over 20char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        # -- �ǡ��������С��ե��������å�(8char)
        if tmp_dict[i]['entry_srv'] and len(tmp_dict[i]['entry_srv']) > 8:
            #print('Invalid entry_srv over 8char:'+str(tmp_dict[i]))
            err_dict.append(tmp_dict[i])
            continue

        tmp_dict[i]['entry_sh'] = hscript
        tmp_dict[i]['time_stamp'] = exec_date
        if re.compile('^'+repf_dir).search(tmp_dict[i]['ctg_dir']):
            tmp_dict[i]['ctg_dirsv'] = tmp_dict[i]['ctg_dir'].replace(repf_dir, rept_dir, 1)
        tmp_dict[i]['seq_value'] = dbid
        out_dict.append(tmp_dict[i])
        dbid += 1

    # -- DB������CSV����
    with open(outfile, 'wt') as wf:
        dict_writer = csv.DictWriter(wf, fieldnames=whedder, extrasaction='ignore')

        dict_writer.writeheader()
        dict_writer.writerows(out_dict)

    # -- ���顼CSV����
    if err_dict:
        with open(errfile, 'wt') as wfe:
            dict_writer = csv.DictWriter(wfe, fieldnames=whedder, extrasaction='ignore')

            dict_writer.writeheader()
            dict_writer.writerows(err_dict)

except Exception as e:
    print(e)
    rc = 99
except ValueError as e:
    print(e)
    rc = 9
finally:
    print('nextdbid:'+str(dbid))
    exit(rc)
