#!/bin/sh
#set -x
######################################################################
#
#                                           by T.Ogata
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ1:IMPPRM〉
#　HOST名 KEYMESSAGE YML
#　h1130045 ORA-11111 1F40h1130045ORA-11111
#　h1130045 ORA-22222 1F40h1130045ORA-22222
#　automa01t001 ORA-11111 1F40automa01t001ORA-11111
######################################################################
# 〈ﾊﾟﾗﾒｰﾀｲﾒｰｼﾞ2:REIGAI.csv〉
#　HOST名 STARTTIME ENDTIME MESSAGE
#　h1130045 201904010000 201904012359 message
#　h1130046 201904010000 202004010000 message
#　h1130047 201904010000 209904012359 message
######################################################################
#　JP1取り込み情報
#  $1 = HOSTANME
#  $2 = JP1MESSAGE
#  $3 = JP1STARTDATE
#  $4 = JP1STARTTIME
######################################################################
INprm=`ls sh/*IMPPRM`
INprm2=`ls sh/*REIGAI.csv`

JP1DATE=`echo "$3""$4" | sed -e 's/\///g' | sed -e 's/://g' | sed -e 's/..$//g'`
JP1DATE2=`date '+%Y%m%d%H%M%S'`

SETPRM1()
{
     PRM1=`echo ${LINE} | awk '{print$1}'`
     PRM2=`echo ${LINE} | awk '{print$2}'`
     PRM3=`echo ${LINE} | awk '{print$3}'`
     PRM4=`echo ${LINE} | awk '{print$4}'`
}

SETPRM2()
{
     PRM5=`echo ${LINE2} | awk '{print$1}'`
     PRM6=`echo ${LINE2} | awk '{print$2}'`
     PRM7=`echo ${LINE2} | awk '{print$3}'`
     PRM8=`echo ${LINE2} | awk '{print$4}'`
}

IFS='
'

for LINE in `cat ${INprm} | grep "$1"`
do
     SETPRM1
       echo "${2}" | grep -E "${PRM2}" > /dev/null 2>&1
       if [ $? = 0 ]
         then
         case "${PRM3}" in
         *)
         for LINE2 in `cat ${INprm2} | grep "$1"`
         do
           SETPRM2
           if [ ${JP1DATE} -ge ${PRM6} ]
             then
             if [ ${JP1DATE} -lt ${PRM7} ]
               then
               echo "${2}" | grep -E "${PRM8}" > /dev/null 2>&1
               if [ $? = 0 ]
                 then
                 echo "非監視イベントです。"
                 exit 0
               fi
             fi
           fi
         done
         for LINE2 in `cat ${INprm2} | grep -E ^"\*"`
         do
           SETPRM2
           if [ ${JP1DATE} -ge ${PRM6} ]
             then
             if [ ${JP1DATE} -lt ${PRM7} ]
               then
               echo "${2}" | grep -E "${PRM8}" > /dev/null 2>&1
               if [ $? = 0 ]
                 then
                 echo "非監視イベントです。"
                 exit 0
               fi
             fi
           fi
         done
         ansible-playbook -i hosts/hosts yml/${PRM3} -vv --extra-vars "JP1MESSAGE=$2 JP1DATE=$JP1DATE2" --vault-password-file ~/ansible/.vault_password
         exit 0
         ;;
         esac
       fi
done

for LINE in `cat ${INprm} | grep -E ^"\*"`
do
     SETPRM1
       echo "${2}" | grep -E "${PRM2}" > /dev/null 2>&1
       if [ $? = 0 ]
         then
         case "${PRM3}" in
         *)
         for LINE2 in `cat ${INprm2} | grep "$1"`
         do
           SETPRM2
           if [ ${JP1DATE} -ge ${PRM6} ]
             then
             if [ ${JP1DATE} -lt ${PRM7} ]
               then
               echo "${2}" | grep -E "${PRM8}" > /dev/null 2>&1
               if [ $? = 0 ]
                 then
                 echo "非監視イベントです。"
                 exit 0
               fi
             fi
           fi
         done
         for LINE2 in `cat ${INprm2} | grep -E ^"\*"`
         do
           SETPRM2
           if [ ${JP1DATE} -ge ${PRM6} ]
             then
             if [ ${JP1DATE} -lt ${PRM7} ]
               then
               echo "${2}" | grep -E "${PRM8}" > /dev/null 2>&1
               if [ $? = 0 ]
                 then
                 echo "非監視イベントです。"
                 exit 0
               fi
             fi
           fi
         done
         ansible-playbook -i hosts/hosts yml/${PRM3} -vv --extra-vars "JP1MESSAGE=$2 JP1DATE=$JP1DATE2" --vault-password-file ~/ansible/.vault_password
         exit 0
         ;;
         esac
       fi
done
echo "対応不要イベントです。"
exit 0
