#!/bin/sh

DATE=`date -d '10 minutes ago' '+%Y%m%d%H%M%S'`
DATE2=`echo $DATE | sed -e 's/...$//'`
DATE3=`date -d '2 days ago' '+%Y%m%d%H%M%S'`

hostname
pwd
echo "$DATE"
echo "$DATE2"
echo "$DATE3"

cat /tmp/jp1test/jp1mail.txt | sed -e 's/_.*$//' > /tmp/jp1test/jp1maildel.txt

for i in `cat /tmp/jp1test/jp1maildel.txt`
do
  if [ `echo $i` -lt `echo $DATE3` ]; then
    echo "削除対象のメッセージがあります。"
    sed -i "/$i\_/d" /tmp/jp1test/jp1mail.txt
  else
    echo "送信対象のメッセージはありませんでした。"
  fi
done

cat /tmp/jp1test/jp1mail.txt | grep "$DATE2" | sed -e "s/$DATE2..._//" > /tmp/jp1test/jp1mail2.txt

