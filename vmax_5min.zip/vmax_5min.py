#!/opt/splunk/bin/python3
from tracemalloc import start
import requests,json,copy
from requests.auth import HTTPBasicAuth
import datetime
import sys, os,csv
import logging, logging.handlers
import splunk
import urllib3
requests.packages.urllib3.disable_warnings()

#Splunk logger設定
def setup_logging():
    logger = logging.getLogger('splunk.foo')    
#    SPLUNK_HOME = os.environ['SPLUNK_HOME']
    SPLUNK_HOME = '/opt/splunk'
    
    LOGGING_DEFAULT_CONFIG_FILE = os.path.join(SPLUNK_HOME, 'etc', 'log.cfg')
    LOGGING_LOCAL_CONFIG_FILE = os.path.join(SPLUNK_HOME, 'etc', 'log-local.cfg')
    LOGGING_STANZA_NAME = 'python'
    LOGGING_FILE_NAME = "VMAX_cron.log"

    BASE_LOG_PATH = os.path.join('var', 'log', 'splunk')
    LOGGING_FORMAT = "%(asctime)s %(levelname)-s\t%(module)s:%(lineno)d - %(message)s"
    splunk_log_handler = logging.handlers.RotatingFileHandler(os.path.join(SPLUNK_HOME, BASE_LOG_PATH, LOGGING_FILE_NAME), mode='a') 
    splunk_log_handler.setFormatter(logging.Formatter(LOGGING_FORMAT))
    logger.addHandler(splunk_log_handler)
    splunk.setupSplunkLogger(logger, LOGGING_DEFAULT_CONFIG_FILE, LOGGING_LOCAL_CONFIG_FILE, LOGGING_STANZA_NAME)
    return logger


def request_post(url_items,item_data,user,passw):
    try:
        r_post = requests.post(url_items,headers=headers,json=item_data,auth=(user, passw),verify=False,timeout=10)

        return(dict(rc=True,r_post=r_post))

    except Exception as e:
        logger.error(str(e))
        print(SCRIPT_NAME+": ERROR: "+str(e), file=sys.stderr)
        return(dict(rc=False,r_post="False"))

#    finally:
#        return(r_post)


logger = setup_logging()

#スクリプト名取得
SCRIPT_NAME=os.path.basename(__file__)

#取得先共通部位定義
headers = {'Content-Type': 'application/json'}

#dir
CONFDIR="/infraunyo/vmax"
OUTPUTDIR="/infraunyo/vmax/output"
TMPDIR="/infraunyo/vmax/tmp"


#conffile
REAL_METRIC_CONF = os.path.join(CONFDIR, 'metrics.conf')
VMAX_CONF=os.path.join(CONFDIR, "vmax.conf")


try:
    logger.info("start")
    with open(REAL_METRIC_CONF,'r',encoding='utf8') as f:
        data=f.read().replace('\n','')
    _metric=data.rstrip().split(',')

    csvf = open(VMAX_CONF,'r',encoding='utf8')
    _vmax = csv.DictReader(csvf)

    #現在の時刻を設定
    now = datetime.datetime.now()
    endDate = int(now.timestamp())*1000

    for lis in _vmax:
        logger.info(str(lis))
        symmetrixId = lis.get('symmetrixId')
        user = lis.get('user')
        passw = lis.get('passw')

        url_items = "https://"+lis.get('IPaddr')+":8443/univmax/restapi/performance/Array/metrics"

        outout_json_path = os.path.join(OUTPUTDIR, symmetrixId)
        os.makedirs(outout_json_path, exist_ok=True)
        outout_json = os.path.join(outout_json_path, 'vmax_history.json')

        lasttime_file = os.path.join(TMPDIR, symmetrixId)

        if os.path.isfile(lasttime_file):
            with open(lasttime_file, 'r') as f:     
                StartDate = int(f.read())
        else:
            StartDate = int((now-datetime.timedelta(minutes=60)).timestamp())*1000


        item_data = {
        "symmetrixId": symmetrixId,
        "endDate": endDate,
        "dataFormat": "Average",
        "metrics": _metric,
        "startDate": StartDate
        }


        logger.info(str(url_items)+" "+str(item_data))

## リクエストは3回繰り返す
        for i in range(3):
            r_post = request_post(url_items,item_data,user,passw)
            if r_post.get('rc') == True:
                if r_post['r_post'].status_code == 200:
                    jsdata =  json.loads(r_post['r_post'].text).get("resultList").get("result")
                    logger.info(str(jsdata))

                    with open(outout_json, 'w') as f:
                        json.dump(jsdata, f, indent=4)
                    logger.info("outputFile "+outout_json)

                    settimestamp = 0
                    for tmp in jsdata:
                        if settimestamp < tmp.get('timestamp',0):
                            settimestamp = tmp.get('timestamp',0)

                    with open(lasttime_file, 'w') as f:
                        f.write(str(settimestamp))

                    break

                else:
                    logger.warning("statuscode error "+str(r_post['r_post'].status_code)+"  "+url_items+" No"+str(i+1))
                    print(SCRIPT_NAME+": WARNING: statuscode error "+str(r_post['r_post'].status_code)+"  "+url_items+" No"+str(i+1), file=sys.stderr)

            else:
                logger.error("Request Error "+url_items+" No"+str(i+1))
                print(SCRIPT_NAME+": ERROR: Request Error "+url_items+" No"+str(i+1), file=sys.stderr)
        else:
             logger.error("Request countover "+url_items+" No"+str(i+1))
             print(SCRIPT_NAME+": ERROR: Request countover "+url_items+" No"+str(i+1), file=sys.stderr)

    csvf.close

    logger.info('NormalEnd')

except Exception as e:
    logger.error('AbnormalEND'+str(e))
    print(SCRIPT_NAME+": ERROR: "+str(e), file=sys.stderr)
